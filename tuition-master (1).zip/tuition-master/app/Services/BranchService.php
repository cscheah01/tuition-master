<?php

namespace App\Services;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\BranchRepository;
use Illuminate\Support\Facades\Validator;

class BranchService extends Service
{
    protected $_branchRepository;

    public function __construct(BranchRepository $_branchRepository)
    {
        $this->_branchRepository = $_branchRepository;
    }

    public function createBranch($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255|unique:branches,name',
                'phone_no' => 'required|string|max:255'
            ]);
            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_branchRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add branch.");

            DB::rollBack();
            return null;
        }
    }

    public function updateBranch($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255|unique:branches,name,' . $id,
                'phone_no' => 'required|string|max:255'
            ]);
            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_branchRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update branch.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('branches')
            ->select(['id', 'name', 'phone_no']);

        $result = DataTables::of($data)->make();

        return $result;
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_branchRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete branch.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        return $this->_branchRepository->getById($id);
    }

    public function getAll()
    {
        return $this->_branchRepository->getAll();
    }
}
