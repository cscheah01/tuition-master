<?php

namespace App\Services;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\AreaRepository;
use Illuminate\Support\Facades\Validator;


class AreaService extends Service
{
    protected $_areaRepository;

    public function __construct(AreaRepository $_areaRepository)
    {
        $this->_areaRepository = $_areaRepository;
    }

    public function createArea($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:areas'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_areaRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add area.");

            DB::rollBack();
            return null;
        }
    }

    public function updateArea($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:areas,name,' . $id
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }



            $result = $this->_areaRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update area.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('areas')
            ->leftjoin('branches', 'areas.branch_id', '=', 'branches.id')
            ->select([
                'areas.id',
                'areas.name',
                'areas.branch_id',
                'branches.name as branch_name',
            ]);

        $result = DataTables::of($data)->make();

        return $result;
    }


    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_areaRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete area.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        return $this->_areaRepository->getById($id);
    }
}
