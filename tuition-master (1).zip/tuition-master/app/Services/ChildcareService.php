<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\DB;
use App\Repositories\ChildcareRepository;
use Illuminate\Support\Facades\Validator;

class ChildcareService extends Service
{
    protected $_childcareRepository;

    public function __construct(ChildcareRepository $_childcareRepository)
    {
        $this->_childcareRepository = $_childcareRepository;
    }

    public function updateTimeSlot($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'day_of_week' => 'required',
                'time_slot' => 'array',
                'time_slot.*.start_time' => 'required|date_format:h:i A',
                'time_slot.*.end_time' => 'required|date_format:h:i A',
                'time_slot.*.teacher_id' => 'required|exists:users,id'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //delete all time slot by day of week
            $this->deleteByDayOfWeek($data['branch_id'], $data['day_of_week']);

            //storing all time slot
            if (isset($data['time_slot'])) {
                $timeSlot = [];
                foreach ($data['time_slot'] as $timeSlot) {
                    $timeSlot['branch_id'] = $data['branch_id'];
                    $timeSlot['day_of_week'] = $data['day_of_week'];

                    $timeSlot[] = $this->_childcareRepository->save($timeSlot);
                }
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update childcare time slot.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteByDayOfWeek($branchId, $dayOfWeek)
    {
        DB::beginTransaction();

        try {
            $data = $this->_childcareRepository->deleteByDayOfWeek($branchId, $dayOfWeek);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete childcare time slot.");

            DB::rollBack();
            return null;
        }
    }

    public function getByBranchId($branchId)
    {
        return $this->_childcareRepository->getByBranchId($branchId);
    }

    public function getSingleDay($branchId, $dayOfWeek)
    {
        $dataFromBranch = $this->_childcareRepository->getByBranchId($branchId);

        $data = $dataFromBranch->where('day_of_week', $dayOfWeek);

        return $data;
    }
}
