<?php

namespace App\Services;

use Exception;
use App\Enums\DayOfWeek;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\SubjectRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\SubjectTimeSlotRepository;


class SubjectService extends Service
{
    protected $_subjectRepository;
    protected $_subjectTimeSlotRepository;

    public function __construct(
        SubjectRepository $_subjectRepository,
        SubjectTimeSlotRepository $_subjectTimeSlotRepository
    ) {
        $this->_subjectRepository = $_subjectRepository;
        $this->_subjectTimeSlotRepository = $_subjectTimeSlotRepository;
    }

    public function createSubject($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:subjects,name,NULL,id,branch_id,' . $data['branch_id'],
                'education_level_id' => 'required|exists:education_levels,id',
                'day_of_week' => 'required|array',
                'day_of_week.*' => 'required',
                'start_time' => 'required|array',
                'start_time.*' => 'required|date_format:h:i A',
                'end_time' => 'required|array',
                'end_time.*' => 'required|date_format:h:i A',
                'teacher_id' => 'required|array',
                'teacher_id.*' => 'required|exists:users,id',
                'classroom_id' => 'required|array',
                'classroom_id.*' => 'required|exists:classrooms,id',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //validation for time slot
            if (
                count($data['day_of_week']) != count($data['start_time']) ||
                count($data['day_of_week']) != count($data['end_time']) ||
                count($data['day_of_week']) != count($data['teacher_id']) ||
                count($data['day_of_week']) != count($data['classroom_id'])
            ) {
                throw new Exception();
            }

            //subject
            $subjectData = [
                'branch_id' => $data['branch_id'],
                'name' => $data['name'],
                'education_level_id' => $data['education_level_id']
            ];

            $subject = $this->_subjectRepository->save($subjectData);

            //subject time slot
            $subjectTimeSlot = [];
            for ($i = 0; $i < count($data['day_of_week']); $i++) {
                $subjectTimeSlotData = [
                    'subject_id' => $subject->id,
                    'day_of_week' => $data['day_of_week'][$i],
                    'start_time' => date("H:i:s", strtotime($data['start_time'][$i])),
                    'end_time' => date("H:i:s", strtotime($data['end_time'][$i])),
                    'teacher_id' => $data['teacher_id'][$i],
                    'classroom_id' => $data['classroom_id'][$i]
                ];

                $subjectTimeSlot[] = $this->_subjectTimeSlotRepository->save($subjectTimeSlotData);
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add subject.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('subjects')
            ->leftjoin('branches', 'subjects.branch_id', '=', 'branches.id')
            ->leftjoin('education_levels', 'subjects.education_level_id', '=', 'education_levels.id')
            ->select([
                'subjects.id',
                'subjects.name',
                'subjects.branch_id',
                'branches.name as branch_name',
                'education_levels.id as education_level_id',
                'education_levels.name as education_level',
            ]);

        $result = DataTables::of($data)
            ->addColumn('available_time', function ($row) {
                $timeslots = DB::table('subject_time_slots')
                    ->where('subject_id', $row->id)
                    ->select([
                        'day_of_week',
                    ])->get();

                $html = "";
                foreach ($timeslots as $timeslot) {
                    $dayOfWeek = DayOfWeek::getKey((int)$timeslot->day_of_week);

                    $html .= "<span class='badge badge-success mr-2'>" . $dayOfWeek . "</span>";
                }
                return  $html;
            })
            ->rawColumns(['available_time'])
            ->make(true);

        return $result;
    }


    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_subjectRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete subject.");

            DB::rollBack();
            return null;
        }
    }
}
