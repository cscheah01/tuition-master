<?php

namespace App\Services;

use Exception;
use App\Models\Role;
use App\Enums\GenderType;
use App\Notifications\UpdatePasswordByAdminNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Repositories\TeacherRepository;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;

class TeacherService extends Service
{
    protected $_teacherRepository;
    protected $_roleOptions;
    protected $_genderOptions;

    public function __construct(TeacherRepository $_teacherRepository)
    {
        $this->_teacherRepository = $_teacherRepository;

        $this->_roleOptions = Role::all()
            ->where('name', '!=', 'Super Admin')
            ->Where('name', '!=', 'Driver')
            ->pluck('id')
            ->toArray();

        $this->_genderOptions = GenderType::getValues();
    }

    public function createTeacher($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255',
                'gender' => 'required|in:' .  implode(',', $this->_genderOptions),
                'phone_no' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users',
                'password' => 'required|string|confirmed|min:8|max:255',
                'is_active' => 'boolean',
                'role_id' => 'required|string|max:255|in:' .  implode(',', $this->_roleOptions),
                'remark' => 'max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_teacherRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add Teacher.");

            DB::rollBack();
            return null;
        }
    }

    public function updateTeacher($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255',
                'gender' => 'required|in:' .  implode(',', $this->_genderOptions),
                'phone_no' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email,' . $id,
                'is_active' => 'boolean',
                'role_id' => 'required|string|max:255|in:' .  implode(',', $this->_roleOptions),
                'remark' => 'max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_teacherRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update teacher.");

            DB::rollBack();
            return null;
        }
    }

    public function updatePassword($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'password' => 'required|string|confirmed|min:8|max:255',
                'send_mail' => 'boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_teacherRepository->updatePassword($data, $id);

            if ($data['send_mail'] == true) {
                $result->notify(new UpdatePasswordByAdminNotification($data['password']));
            }

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update password.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('users')
            ->leftjoin('branches', 'users.branch_id', '=', 'branches.id')
            ->leftjoin('roles', 'users.role_id', '=', 'roles.id')
            ->where('roles.name', '!=', 'Driver')
            ->where('roles.name', '!=', 'Super Admin')
            ->select([
                'users.id',
                'users.name',
                'users.gender',
                'users.branch_id',
                'branches.name as branch_name',
                'users.phone_no',
                'users.email',
                'users.role_id',
                'roles.name as role_name',
                'users.is_active'
            ]);
        $result = DataTables::of($data)->make();

        return $result;
    }


    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_teacherRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete teacher.");

            DB::rollBack();
            return null;
        }
    }

    public function getAll()
    {
        return $this->_teacherRepository->getAll();
    }

    public function getById($id)
    {
        return $this->_teacherRepository->getById($id);
    }
}
