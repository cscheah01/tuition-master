<?php

namespace App\Services;

use Exception;
use App\Models\School;
use InvalidArgumentException;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Repositories\SchoolRepository;
use Illuminate\Support\Facades\Validator;

class SchoolService extends Service
{
    protected $_schoolRepository;

    public function __construct(SchoolRepository $_schoolRepository)
    {
        $this->_schoolRepository = $_schoolRepository;
    }

    public function createSchool($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255|unique:schools,name',
                'branch_id' => 'required'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_schoolRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add school.");

            DB::rollBack();
            return null;
        }
    }

    public function updateSchool($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:schools,name,' . $id
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_schoolRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update school.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('schools')
            ->leftjoin('branches', 'schools.branch_id', '=', 'branches.id')
            ->select(['schools.id', 'schools.name', 'schools.branch_id', 'branches.name as branch_name']);

        $result = DataTables::of($data)->make();

        return $result;
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_schoolRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete school.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        return $this->_schoolRepository->getById($id);
    }
}
