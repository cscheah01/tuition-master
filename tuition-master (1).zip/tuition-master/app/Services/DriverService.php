<?php

namespace App\Services;

use Exception;
use App\Models\Role;
use App\Enums\GenderType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\DriverRepository;
use Illuminate\Support\Facades\Validator;
use App\Notifications\UpdatePasswordByAdminNotification;

class DriverService extends Service
{
    protected $_driverRepository;

    public function __construct(DriverRepository $_driverRepository)
    {
        $this->_driverRepository = $_driverRepository;
    }

    public function createDriver($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255',
                'phone_no' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users',
                'plate_no' => 'required|string|max:255',
                'password' => 'required|string|confirmed|min:8|max:255',
                'is_active' => 'boolean',
                'remark' => 'max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_driverRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add driver.");

            DB::rollBack();
            return null;
        }
    }

    public function updateDriver($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255',
                'phone_no' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email,' . $id,
                'plate_no' => 'required|string|max:255',
                'is_active' => 'boolean',
                'remark' => 'max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_driverRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update driver.");

            DB::rollBack();
            return null;
        }
    }

    public function updatePassword($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'password' => 'required|string|confirmed|min:8|max:255',
                'send_mail' => 'boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_driverRepository->updatePassword($data, $id);

            if ($data['send_mail'] == true) {
                $result->notify(new UpdatePasswordByAdminNotification($data['password']));
            }

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update password.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_driverRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete driver.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        return $this->_driverRepository->getById($id);
    }

    public function getDataTable()
    {
        $data = DB::table('users')
            ->leftjoin('branches', 'users.branch_id', '=', 'branches.id')
            ->leftjoin('roles', 'users.role_id', '=', 'roles.id')
            ->where('roles.name', '=', 'Driver')
            ->select([
                'users.id',
                'users.name',
                'users.branch_id',
                'branches.name as branch_name',
                'users.plate_no',
                'users.phone_no',
                'users.is_active',
                'users.remark'
            ]);

        $result = DataTables::of($data)->make();

        return $result;
    }
}
