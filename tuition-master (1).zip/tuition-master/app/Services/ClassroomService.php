<?php

namespace App\Services;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ClassroomRepository;
use Illuminate\Support\Facades\Validator;

class ClassroomService extends Service
{
    protected $_classroomRepository;

    public function __construct(ClassroomRepository $_classroomRepository)
    {
        $this->_classroomRepository = $_classroomRepository;
    }


    public function createClassroom($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:classrooms'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_classroomRepository->save($data);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add classroom.");

            DB::rollBack();
            return null;
        }
    }

    public function updateClassroom($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'name' => 'required|string|max:255|unique:classrooms,name,' . $id
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_classroomRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update classroom.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('classrooms')
            ->leftjoin('branches', 'classrooms.branch_id', '=', 'branches.id')
            ->select([
                'classrooms.id',
                'classrooms.name',
                'classrooms.branch_id',
                'branches.name as branch_name',
            ]);

        $result = DataTables::of($data)->make();

        return $result;
    }


    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $data = $this->_classroomRepository->deleteById($id);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete classroom.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        return $this->_classroomRepository->getById($id);
    }

    public function getAll()
    {
        return $this->_classroomRepository->getAll();
    }
}
