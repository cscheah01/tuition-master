<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\DB;
use App\Repositories\HomeworkRepository;
use Illuminate\Support\Facades\Validator;

class HomeworkService extends Service
{
    protected $_homeworkRepository;

    public function __construct(HomeworkRepository $_homeworkRepository)
    {
        $this->_homeworkRepository = $_homeworkRepository;
    }

    public function updateTimeSlot($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'branch_id' => 'required',
                'day_of_week' => 'required',
                'time_slot' => 'array',
                'time_slot.*.start_time' => 'required|date_format:h:i A',
                'time_slot.*.end_time' => 'required|date_format:h:i A',
                'time_slot.*.teacher_id' => 'required|exists:users,id'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //delete all time slot by day of week
            $this->deleteByDayOfWeek($data['branch_id'], $data['day_of_week']);

            //storing all time slot
            if (isset($data['time_slot'])) {
                $timeSlot = [];
                foreach ($data['time_slot'] as $timeSlot) {
                    $timeSlot['branch_id'] = $data['branch_id'];
                    $timeSlot['day_of_week'] = $data['day_of_week'];

                    $timeSlot[] = $this->_homeworkRepository->save($timeSlot);
                }
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update homework time slot.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteByDayOfWeek($branchId, $dayOfWeek)
    {
        DB::beginTransaction();

        try {
            $data = $this->_homeworkRepository->deleteByDayOfWeek($branchId, $dayOfWeek);

            DB::commit();
            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete homework time slot.");

            DB::rollBack();
            return null;
        }
    }

    public function getByBranchId($branchId)
    {
        return $this->_homeworkRepository->getByBranchId($branchId);
    }

    public function getSingleDay($branchId, $dayOfWeek)
    {
        $dataFromBranch = $this->_homeworkRepository->getByBranchId($branchId);

        $data = $dataFromBranch->where('day_of_week', $dayOfWeek);

        return $data;
    }
}
