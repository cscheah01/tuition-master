<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Http\Request;
use Laravel\Fortify\Fortify;
use App\Models\PasswordReset;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;
use App\Actions\Fortify\CreateNewUser;
use Illuminate\Support\ServiceProvider;
use Illuminate\Cache\RateLimiting\Limit;
use App\Actions\Fortify\ResetUserPassword;
use App\Actions\Fortify\UpdateUserPassword;
use Illuminate\Support\Facades\RateLimiter;
use App\Actions\Fortify\UpdateUserProfileInformation;

class FortifyServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        Fortify::ignoreRoutes(); //ignore default route at vendor file, custom declare at /routes/web.php
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        /*

        RateLimiter::for('two-factor', function (Request $request) {
            return Limit::perMinute(5)->by($request->session()->get('login.id'));
        });

        */

        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by($request->email . $request->ip());
        });

        Fortify::loginView(function () {
            return view('auth/login');
        });

        Fortify::authenticateUsing(function (Request $request) {
            $user = User::where('email', $request->email)->first();

            if (
                $user &&
                Hash::check($request->password, $user->password)
            ) {
                return $user;
            }
        });

        Fortify::registerView(function () {
            return view('auth/register');
        });

        Fortify::requestPasswordResetLinkView(function () {
            return view('auth/forgot-password');
        });

        Fortify::resetPasswordView(function ($request) {
            $data = PasswordReset::where('email', urldecode(request()->get('email')))->first();
            $tokenExpiredDate = Carbon::parse($data->created_at)->addSeconds(config('auth.passwords.users.expire') * 60);

            if (!$data || !Hash::check(request()->token, $data->token)) {
                // if email or token not match, return 404
                abort(404);
            } else if ($tokenExpiredDate->isPast() == true) {
                // if token expired, return 404
                abort(404);
            }

            return view('auth/reset-password', ['request' => $request]);
        });

        Fortify::verifyEmailView(function () {
            return view('auth/verify-email');
        });

        Fortify::createUsersUsing(CreateNewUser::class);
        Fortify::updateUserProfileInformationUsing(UpdateUserProfileInformation::class);
        Fortify::updateUserPasswordsUsing(UpdateUserPassword::class);
        Fortify::resetUserPasswordsUsing(ResetUserPassword::class);
    }
}
