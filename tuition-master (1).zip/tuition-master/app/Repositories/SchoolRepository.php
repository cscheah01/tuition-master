<?php

namespace App\Repositories;

use App\Models\School;

class SchoolRepository extends Repository
{
    protected $_db;

    public function __construct(School $school)
    {
        $this->_db = $school::with('branch');
    }

    public function save($data)
    {
        $school = new School;
        $school->name = $data['name'];
        $school->branch_id = $data['branch_id'];

        $school->save();
        return $school->fresh();
    }

    public function update($data, $id)
    {
        $school = $this->_db->find($id);
        $school->branch_id = $data['branch_id'];
        $school->name = $data['name'];

        $school->update();
        return $school;
    }
}
