<?php

namespace App\Repositories;

use App\Models\Branch;

class BranchRepository extends Repository
{
    protected $_db;

    public function __construct(Branch $branch)
    {
        $this->_db = $branch;
    }

    public function save($data)
    {
        $branch = new Branch;
        $branch->name = $data['name'];
        $branch->phone_no = $data['phone_no'];

        $branch->save();
        return $branch->fresh();
    }

    public function update($data, $id)
    {
        $branch = $this->_db->find($id);
        $branch->name = $data['name'];
        $branch->phone_no = $data['phone_no'];

        $branch->update();
        return $branch;
    }
}
