<?php

namespace App\Repositories;

use App\Models\Subject;

class SubjectRepository extends Repository
{
    protected $_db;

    public function __construct(Subject $subject)
    {
        $this->_db = $subject::with('branch', 'education_level');
    }

    public function save($data)
    {
        $subject = new Subject;
        $subject->branch_id = $data['branch_id'];
        $subject->name = $data['name'];
        $subject->education_level_id = $data['education_level_id'];

        $subject->save();
        return $subject->fresh();
    }

    /*
    public function update($data, $id)
    {
        $area = $this->_db->find($id);
        $area->branch_id = $data['branch_id'];
        $area->name = $data['name'];

        $area->update();
        return $area;
    }
    */
}
