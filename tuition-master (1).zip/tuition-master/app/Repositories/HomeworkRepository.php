<?php

namespace App\Repositories;

use App\Models\HomeworkTimeSlot;

class HomeworkRepository extends Repository
{
    protected $_db;

    public function __construct(HomeworkTimeSlot $_homeworkTimeSlot)
    {
        $this->_db = $_homeworkTimeSlot::with('branch', 'teacher');
    }

    public function save($data)
    {
        $timeSlot = new HomeworkTimeSlot;
        $timeSlot->branch_id = $data['branch_id'];
        $timeSlot->day_of_week = $data['day_of_week'];
        $timeSlot->start_time = date("H:i:s", strtotime($data['start_time']));
        $timeSlot->end_time = date("H:i:s", strtotime($data['end_time']));
        $timeSlot->teacher_id = $data['teacher_id'];

        $timeSlot->save();
        return $timeSlot->fresh();
    }

    public function deleteByDayOfWeek($branchId, $dayOfWeek)
    {
        $timeSlot = $this->_db->where('branch_id', $branchId)
            ->where('day_of_week', $dayOfWeek);

        $timeSlot->delete();
        return $timeSlot;
    }

    public function getByBranchId($branchId)
    {
        $data = $this->_db->where('branch_id', $branchId)->get();

        return $data;
    }
}
