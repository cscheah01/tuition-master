<?php

namespace App\Repositories;

use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DriverRepository extends Repository
{
    protected $_db;

    public function __construct(User $driver)
    {
        $this->_db = $driver
            ->whereHas('role', function ($query) {
                $query->where('name', 'Driver');;
            })
            ->with('branch');;
    }

    public function save($data)
    {
        $driver = new User;
        $driver->branch_id = $data['branch_id'];
        $driver->name = $data['name'];
        $driver->phone_no = $data['phone_no'];
        $driver->plate_no = $data['plate_no'];
        $driver->email = $data['email'];
        $driver->password = Hash::make($data['password']);
        $driver->is_active = $data['is_active'];
        $driver->role_id = Role::where("name", "Driver")->first()->id;
        $driver->remark = $data['remark'];

        $driver->save();
        return $driver->fresh();
    }

    public function update($data, $id)
    {
        $driver = $this->_db->find($id);
        $driver->branch_id = $data['branch_id'];
        $driver->name = $data['name'];
        $driver->phone_no = $data['phone_no'];
        $driver->plate_no = $data['plate_no'];
        $driver->email = $data['email'];
        $driver->is_active = $data['is_active'];
        $driver->remark = $data['remark'];

        $driver->update();
        return $driver;
    }

    public function updatePassword($data, $id)
    {
        $driver = $this->_db->find($id);
        $driver->password = Hash::make($data['password']);

        $driver->update();
        return $driver;
    }
}
