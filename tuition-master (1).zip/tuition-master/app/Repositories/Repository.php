<?php

namespace App\Repositories;


class Repository
{
    public function getAll()
    {
        $data = $this->_db->get();

        if ($data == null) {
            return null;
        }

        return $data;
    }

    public function getById($id)
    {
        $data = $this->_db->find($id);

        if ($data == null) {
            return null;
        }

        return $data;
    }

    public function deleteById($id)
    {
        $data = $this->getById($id);

        if ($data == null) {
            return null;
        }

        $data->delete();

        return $data;
    }
}
