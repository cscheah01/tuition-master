<?php

namespace App\Repositories;

use App\Models\Area;

class AreaRepository extends Repository
{
    protected $_db;

    public function __construct(Area $area)
    {
        $this->_db = $area::with('branch');
    }

    public function save($data)
    {
        $area = new Area;
        $area->branch_id = $data['branch_id'];
        $area->name = $data['name'];

        $area->save();
        return $area->fresh();
    }

    public function update($data, $id)
    {
        $area = $this->_db->find($id);
        $area->branch_id = $data['branch_id'];
        $area->name = $data['name'];

        $area->update();
        return $area;
    }
}
