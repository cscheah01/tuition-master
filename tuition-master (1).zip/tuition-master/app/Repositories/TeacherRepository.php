<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

class TeacherRepository extends Repository
{
    protected $_db;

    public function __construct(User $teacher)
    {
        $this->_db = $teacher
            ->whereHas('role', function ($query) {
                $query->where('name', '!=', 'Driver')
                    ->where('name', '!=', 'Super Admin');
            })
            ->with('branch');
    }

    public function save($data)
    {
        $teacher = new User;
        $teacher->branch_id = $data['branch_id'];
        $teacher->name = $data['name'];
        $teacher->gender = $data['gender'];
        $teacher->phone_no = $data['phone_no'];
        $teacher->email = $data['email'];
        $teacher->password = Hash::make($data['password']);
        $teacher->is_active = $data['is_active'];
        $teacher->role_id = $data['role_id'];
        $teacher->remark = $data['remark'];

        $teacher->save();
        return $teacher->fresh();
    }

    public function update($data, $id)
    {
        $teacher = $this->_db->find($id);
        $teacher->branch_id = $data['branch_id'];
        $teacher->name = $data['name'];
        $teacher->gender = $data['gender'];
        $teacher->phone_no = $data['phone_no'];
        $teacher->email = $data['email'];
        $teacher->is_active = $data['is_active'];
        $teacher->role_id = $data['role_id'];
        $teacher->remark = $data['remark'];

        $teacher->update();
        return $teacher;
    }

    public function updatePassword($data, $id)
    {
        $teacher = $this->_db->find($id);
        $teacher->password = Hash::make($data['password']);

        $teacher->update();
        return $teacher;
    }
}
