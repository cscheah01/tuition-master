<?php

namespace App\Repositories;

use App\Models\SubjectTimeSlot;

class SubjectTimeSlotRepository extends Repository
{
    protected $_db;

    public function __construct(SubjectTimeSlot $subjectTimeSlot)
    {
        $this->_db = $subjectTimeSlot::with('subject', 'teacher', 'classroom_id');
    }

    public function save($data)
    {
        $subjectTimeSlot = new SubjectTimeSlot;
        $subjectTimeSlot->subject_id = $data['subject_id'];
        $subjectTimeSlot->day_of_week = $data['day_of_week'];
        $subjectTimeSlot->start_time = $data['start_time'];
        $subjectTimeSlot->end_time = $data['end_time'];
        $subjectTimeSlot->teacher_id = $data['teacher_id'];
        $subjectTimeSlot->classroom_id = $data['classroom_id'];

        $subjectTimeSlot->save();
        return $subjectTimeSlot->fresh();
    }

    /*
    public function update($data, $id)
    {
        $area = $this->_db->find($id);
        $area->branch_id = $data['branch_id'];
        $area->name = $data['name'];

        $area->update();
        return $area;
    }
    */
}
