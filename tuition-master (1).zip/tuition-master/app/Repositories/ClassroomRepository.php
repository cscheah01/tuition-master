<?php

namespace App\Repositories;

use App\Models\Classroom;

class ClassroomRepository extends Repository
{
    protected $_db;

    public function __construct(Classroom $classroom)
    {
        $this->_db = $classroom::with('branch');
    }

    public function save($data)
    {
        $classroom = new Classroom;
        $classroom->branch_id = $data['branch_id'];
        $classroom->name = $data['name'];

        $classroom->save();
        return $classroom->fresh();
    }

    public function update($data, $id)
    {
        $classroom = $this->_db->find($id);
        $classroom->branch_id = $data['branch_id'];
        $classroom->name = $data['name'];

        $classroom->update();
        return $classroom;
    }
}
