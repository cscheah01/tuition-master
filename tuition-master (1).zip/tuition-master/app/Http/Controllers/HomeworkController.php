<?php

namespace App\Http\Controllers;

use App\Enums\DayOfWeek;
use Illuminate\Http\Request;
use App\Services\BranchService;
use App\Services\TeacherService;
use App\Services\HomeworkService;
use Illuminate\Support\Facades\Redirect;

class HomeworkController extends Controller
{
    private $_homeworkService;
    private $_branchService;
    private $_teacherService;

    public function __construct(
        HomeworkService $_homeworkService,
        BranchService $_branchService,
        TeacherService $_teacherService
    ) {
        $this->_homeworkService = $_homeworkService;
        $this->_branchService = $_branchService;
        $this->_teacherService = $_teacherService;
    }


    public function index()
    {
        $branches = $this->_branchService->getAll();
        $dayOfWeek = DayOfWeek::asSelectArray();
        $branchId = auth()->user()->branch_id;
        $homeworkTimeSlots = $this->_homeworkService->getByBranchId($branchId);

        return view('homework.index', compact('branches', 'dayOfWeek', 'homeworkTimeSlots', 'branchId'));
    }

    public function create()
    {
        abort(404);
    }

    public function store(Request $request)
    {
        abort(404);
    }

    public function show($branchId, $dayOfWeek)
    {
        $homeworkTimeSlots = $this->_homeworkService->getSingleDay($branchId, $dayOfWeek);

        if ($homeworkTimeSlots == null) {
            abort(404);
        }

        $dayName = DayOfWeek::getKey((int)$dayOfWeek);
        $teachers = $this->_teacherService->getAll();

        return view('homework.view', compact('dayName', 'dayOfWeek', 'branchId', 'homeworkTimeSlots', 'teachers'));
    }

    public function update(Request $request, $branchId)
    {
        $data = $request->only([
            'day_of_week',
            'time_slot'
        ]);
        $data['branch_id'] = $branchId;

        $result = $this->_homeworkService->updateTimeSlot($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_homeworkService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('homework.show', ['branchId' => $data['branch_id'], 'dayOfWeek' => $data['day_of_week']])->with('success', "Homework Time Slot successfully updated.");
    }

    public function destroy($id)
    {
        abort(404);
    }

    public function dataTable($branchId)
    {
        $dayOfWeek = DayOfWeek::asSelectArray();
        $homeworkTimeSlots = $this->_homeworkService->getByBranchId($branchId);

        return view('homework.index-table', compact('dayOfWeek', 'homeworkTimeSlots', 'branchId'));
    }
}
