<?php

namespace App\Http\Controllers;

use App\Enums\DayOfWeek;
use Illuminate\Http\Request;
use App\Models\EducationLevel;
use App\Services\BranchService;
use App\Services\ClassroomService;
use App\Services\SubjectService;
use App\Services\TeacherService;
use Illuminate\Support\Facades\Redirect;

class SubjectController extends Controller
{
    private $_subjectService;
    private $_branchService;
    private $_teacherService;
    private $_classroomService;

    public function __construct(
        SubjectService $_subjectService,
        BranchService $_branchService,
        TeacherService $_teacherService,
        ClassroomService $_classroomService
    ) {
        $this->_subjectService = $_subjectService;
        $this->_branchService = $_branchService;
        $this->_teacherService = $_teacherService;
        $this->_classroomService = $_classroomService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();
        $educationLevels = EducationLevel::all();

        return view('subject/index', compact('branches', 'educationLevels'));
    }

    public function create()
    {
        $branches = $this->_branchService->getAll();
        $educationLevels = EducationLevel::all();
        $dayOfWeek = DayOfWeek::asSelectArray();
        $teachers = $this->_teacherService->getAll();
        $classrooms = $this->_classroomService->getAll();

        return view('subject/create', compact('branches', 'educationLevels', 'dayOfWeek', 'teachers', 'classrooms'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'branch_id',
            'name',
            'education_level_id',
            'day_of_week',
            'start_time',
            'end_time',
            'teacher_id',
            'classroom_id'
        ]);

        $result = $this->_subjectService->createSubject($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_subjectService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Subject successfully added.");
    }

    public function show($id)
    {
        abort(404);
    }

    public function update(Request $request, $id)
    {
        abort(404);
    }

    public function destroy($id)
    {
        $result = $this->_subjectService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_subjectService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('subject.index')->with('success', "Subject successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_subjectService->getDataTable();

        return $data;
    }
}
