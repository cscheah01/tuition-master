<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BranchService;
use App\Services\DriverService;
use Illuminate\Support\Facades\Redirect;

class DriverController extends Controller
{
    private $_driverService;
    private $_branchService;

    public function __construct(
        DriverService $_driverService,
        BranchService $_branchService
    ) {
        $this->_driverService = $_driverService;
        $this->_branchService = $_branchService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();

        return view('driver/index', compact('branches'));
    }

    public function create()
    {
        $branches = $this->_branchService->getAll();

        return view('driver/create', compact('branches'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'branch_id',
            'name',
            'phone_no',
            'plate_no',
            'email',
            'password',
            'password_confirmation',
            'is_active',
            'remark'
        ]);

        $data['is_active'] = isset($data['is_active']) ? true : false;

        $result = $this->_driverService->createDriver($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_driverService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('driver.show', $result->id)->with('success', "Driver successfully added.");
    }

    public function show($id)
    {
        $driver = $this->_driverService->getById($id);
        $branches = $this->_branchService->getAll();

        return view('driver/view', compact('driver', 'branches'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'branch_id',
            'name',
            'phone_no',
            'plate_no',
            'email',
            'is_active',
            'remark'
        ]);

        $data['is_active'] = isset($data['is_active']) ? true : false;

        $result = $this->_driverService->updateDriver($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_driverService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('driver.show', [$result->id])->with('success', "Driver successfully updated.");
    }

    public function updatePassword(Request $request, $id)
    {
        $data = $request->only([
            'password',
            'password_confirmation',
            'send_mail'
        ]);
        $data['send_mail'] = $request->has('send_mail');

        $result = $this->_driverService->updatePassword($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_driverService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('driver.show', [$result->id])->with('success', "Password successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_driverService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_driverService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('driver.index')->with('success', "Driver successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_driverService->getDataTable();

        return $data;
    }
}
