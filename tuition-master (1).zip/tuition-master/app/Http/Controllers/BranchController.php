<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BranchService;
use Illuminate\Support\Facades\Redirect;

class BranchController extends Controller
{
    private $_branchService;

    public function __construct(BranchService $_branchService)
    {
        $this->_branchService = $_branchService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();

        return view('branch/index', compact('branches'));
    }

    public function create()
    {
        return view('branch/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'phone_no',
        ]);

        $result = $this->_branchService->createBranch($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_branchService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('branch.show',  $result->id)->with('success', "Branch successfully added.");
    }

    public function show($id)
    {
        $branch = $this->_branchService->getById($id);

        return view('branch/view', compact('branch'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'phone_no',
        ]);

        $result = $this->_branchService->updateBranch($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_branchService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('branch.show',  $result->id)->with('success', "Branch successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_branchService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_branchService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('branch.index')->with('success', "Branch successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_branchService->getDataTable();

        return $data;
    }
}
