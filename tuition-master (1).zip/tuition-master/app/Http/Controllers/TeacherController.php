<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\Branch;
use App\Enums\GenderType;
use Illuminate\Http\Request;
use App\Services\BranchService;
use App\Services\TeacherService;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Redirect;

class TeacherController extends Controller
{
    private $_teacherService;
    private $_branchService;

    public function __construct(
        TeacherService $_teacherService,
        BranchService $_branchService
    ) {
        $this->_teacherService = $_teacherService;
        $this->_branchService = $_branchService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();
        $genders = GenderType::asSelectArray();
        $roles = Role::all()
            ->where('name', '!=', 'Super Admin')
            ->Where('name', '!=', 'Driver');

        return view('teacher/index', compact('branches', 'genders', 'roles'));
    }

    public function create()
    {
        $branches = $this->_branchService->getAll();
        $roles = Role::all()
            ->where('name', '!=', 'Super Admin')
            ->Where('name', '!=', 'Driver');
        $genders = GenderType::asSelectArray();

        return view('teacher/create', compact('branches', 'roles', 'genders'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'branch_id',
            'name',
            'gender',
            'phone_no',
            'email',
            'password',
            'password_confirmation',
            'is_active',
            'role_id',
            'remark'
        ]);

        $data['is_active'] = isset($data['is_active']) ? true : false;

        $result = $this->_teacherService->createTeacher($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_teacherService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('teacher.show', $result->id)->with('success', "Teacher successfully added.");
    }

    public function show($id)
    {
        $teacher = $this->_teacherService->getById($id);
        $branches = $this->_branchService->getAll();
        $roles = Role::all()
            ->where('name', '!=', 'Super Admin')
            ->Where('name', '!=', 'Driver');
        $genders = GenderType::asSelectArray();

        return view('teacher/view', compact('teacher', 'branches', 'roles', 'genders'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'branch_id',
            'name',
            'gender',
            'phone_no',
            'email',
            'is_active',
            'role_id',
            'remark'
        ]);
        $data['is_active'] = isset($data['is_active']) ? true : false;

        $result = $this->_teacherService->updateTeacher($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_teacherService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('teacher.show', [$result->id])->with('success', "Teacher successfully updated.");
    }

    public function updatePassword(Request $request, $id)
    {
        $data = $request->only([
            'password',
            'password_confirmation',
            'send_mail'
        ]);
        $data['send_mail'] = $request->has('send_mail');

        $result = $this->_teacherService->updatePassword($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_teacherService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('teacher.show', [$result->id])->with('success', "Password successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_teacherService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_teacherService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('teacher.index')->with('success', "Teacher successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_teacherService->getDataTable();

        return $data;
    }
}
