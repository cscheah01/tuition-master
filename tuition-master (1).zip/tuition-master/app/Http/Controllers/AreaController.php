<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\AreaService;
use App\Services\BranchService;
use Illuminate\Support\Facades\Redirect;

class AreaController extends Controller
{
    private $_areaService;
    private $_branchService;

    public function __construct(AreaService $_areaService, BranchService $_branchService)
    {
        $this->_areaService = $_areaService;
        $this->_branchService = $_branchService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();

        return view('area/index', compact('branches'));
    }

    public function create()
    {
        $branches = $this->_branchService->getAll();

        return view('area/create', compact('branches'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'branch_id',
            'name'
        ]);

        $result = $this->_areaService->createArea($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_areaService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('area.show', [$result->id])->with('success', "Area successfully added.");
    }

    public function show($id)
    {
        $area = $this->_areaService->getById($id);
        $branches = $this->_branchService->getAll();

        return view('area/view', compact('area', 'branches'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'branch_id',
            'name'
        ]);

        $result = $this->_areaService->updateArea($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_areaService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('area.show', [$result->id])->with('success', "Area successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_areaService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_areaService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('area.index')->with('success', "Area successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_areaService->getDataTable();

        return $data;
    }
}
