<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BranchService;
use App\Services\ClassroomService;
use Illuminate\Support\Facades\Redirect;

class ClassroomController extends Controller
{
    private $_classroomService;
    private $_branchService;

    public function __construct(
        ClassroomService $_classroomService,
        BranchService $_branchService
    ) {
        $this->_classroomService = $_classroomService;
        $this->_branchService = $_branchService;
    }

    public function index()
    {
        $branches = $this->_branchService->getAll();

        return view('classroom/index', compact('branches'));
    }

    public function create()
    {
        $branches = $this->_branchService->getAll();

        return view('classroom/create', compact('branches'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'branch_id',
            'name'
        ]);

        $result = $this->_classroomService->createClassroom($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_classroomService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('classroom.show', $result->id)->with('success', "Classroom successfully added.");
    }

    public function show($id)
    {
        $classroom = $this->_classroomService->getById($id);
        $branches = $this->_branchService->getAll();

        return view('classroom/view', compact('classroom', 'branches'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'branch_id',
            'name'
        ]);

        $result = $this->_classroomService->updateClassroom($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_classroomService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('classroom.show', $result->id)->with('success', "Classroom successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_classroomService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_classroomService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('classroom.index')->with('success', "Classroom successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_classroomService->getDataTable();

        return $data;
    }
}
