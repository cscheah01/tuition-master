<?php

namespace App\Http\Controllers;

use App\Enums\DayOfWeek;
use Illuminate\Http\Request;
use App\Services\BranchService;
use App\Services\TeacherService;
use App\Services\ChildcareService;
use Illuminate\Support\Facades\Redirect;

class ChildcareController extends Controller
{
    private $_childcareService;
    private $_branchService;
    private $_teacherService;

    public function __construct(
        ChildcareService $_childcareService,
        BranchService $_branchService,
        TeacherService $_teacherService
    ) {
        $this->_childcareService = $_childcareService;
        $this->_branchService = $_branchService;
        $this->_teacherService = $_teacherService;
    }


    public function index()
    {
        $branches = $this->_branchService->getAll();
        $dayOfWeek = DayOfWeek::asSelectArray();
        $branchId = auth()->user()->branch_id;
        $childcareTimeSlots = $this->_childcareService->getByBranchId($branchId);

        return view('childcare.index', compact('branches', 'dayOfWeek', 'childcareTimeSlots', 'branchId'));
    }

    public function create()
    {
        abort(404);
    }

    public function store(Request $request)
    {
        abort(404);
    }

    public function show($branchId, $dayOfWeek)
    {
        $childcareTimeSlots = $this->_childcareService->getSingleDay($branchId, $dayOfWeek);

        if ($childcareTimeSlots == null) {
            abort(404);
        }

        $dayName = DayOfWeek::getKey((int)$dayOfWeek);
        $teachers = $this->_teacherService->getAll();

        return view('childcare.view', compact('dayName', 'dayOfWeek', 'branchId', 'childcareTimeSlots', 'teachers'));
    }

    public function update(Request $request, $branchId)
    {
        $data = $request->only([
            'day_of_week',
            'time_slot'
        ]);
        $data['branch_id'] = $branchId;

        $result = $this->_childcareService->updateTimeSlot($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_childcareService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('childcare.show', ['branchId' => $data['branch_id'], 'dayOfWeek' => $data['day_of_week']])->with('success', "Childcare Time Slot successfully updated.");
    }

    public function destroy($id)
    {
        abort(404);
    }

    public function dataTable($branchId)
    {
        $dayOfWeek = DayOfWeek::asSelectArray();
        $childcareTimeSlots = $this->_childcareService->getByBranchId($branchId);

        return view('childcare.index-table', compact('dayOfWeek', 'childcareTimeSlots', 'branchId'));
    }
}
