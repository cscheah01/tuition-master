<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChildcareTimeSlotsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('childcare_time_slots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained();
            $table->string('day_of_week');
            $table->time('start_time');
            $table->time('end_time');
            $table->foreignId('teacher_id')->constrained('users');
            $table->timestamps();
        });

        DB::table('childcare_time_slots')->insert([
            [
                'branch_id' => '1',
                'day_of_week' => '1',
                'start_time' => date("H:i:s", strtotime("10:00 AM")),
                'end_time' => date("H:i:s", strtotime("10:00 AM")),
                'teacher_id' => '2'
            ],
            [
                'branch_id' => '1',
                'day_of_week' => '1',
                'start_time' => date("H:i:s", strtotime("11:00 AM")),
                'end_time' => date("H:i:s", strtotime("10:00 AM")),
                'teacher_id' => '2'
            ]
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('childcare_time_slots');
    }
}
