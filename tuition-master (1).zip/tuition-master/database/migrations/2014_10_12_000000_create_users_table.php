<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('gender')->nullable();
            $table->string('phone_no');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken()->nullable();
            $table->string('remark')->nullable();
            $table->string('plate_no')->nullable();
            $table->foreignId('role_id')->constrained();
            $table->foreignId('branch_id')->constrained();
            $table->boolean('is_active');
            $table->timestamps();
        });

        DB::table('users')->insert([
            [
                'name' => 'admin',
                'gender' => '1',
                'phone_no' => '011-11421029',
                'email' => 'admin@admin.com',
                'password' => Hash::make('12345678'),
                'role_id' => '1',
                'branch_id' => '1',
                'is_active' => true
            ]
        ]);

        DB::table('users')->insert([
            [
                'name' => 'teacher won',
                'gender' => '1',
                'phone_no' => '011-11421029',
                'email' => 'teacher@teacher.com',
                'password' => Hash::make('12345678'),
                'role_id' => '3',
                'branch_id' => '1',
                'is_active' => true
            ]
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
