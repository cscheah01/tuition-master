<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEducationLevelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('education_levels', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->timestamps();
        });

        DB::table('education_levels')->insert([
            [
                'name' => 'K1'
            ],
            [
                'name' => 'K2'
            ],
            [
                'name' => 'P1'
            ],
            [
                'name' => 'P2'
            ],
            [
                'name' => 'P3'
            ],
            [
                'name' => 'P4'
            ],
            [
                'name' => 'P5'
            ],
            [
                'name' => 'P6'
            ],
            [
                'name' => 'F1'
            ],
            [
                'name' => 'F2'
            ],
            [
                'name' => 'F3'
            ],
            [
                'name' => 'F4'
            ],
            [
                'name' => 'F5'
            ]
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('education_levels');
    }
}
