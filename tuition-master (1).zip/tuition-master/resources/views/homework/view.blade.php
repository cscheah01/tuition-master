@extends('layout/layout')

@section('page_title', 'Homework - ' . $dayName)

@section('content')
    <div class="container-fluid px-sm-4">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2 px-0">
                    <div class="col-sm-8 px-0">
                        <h1 class="m-0 d-none d-sm-block">
                            Homework - {{ $dayName }}
                        </h1>
                        <h4 class="m-0 d-block d-sm-none">Homework - {{ $dayName }}</h4>
                    </div>
                    <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                        <div class="float-sm-right">
                            <button class="btn-back btn btn-default" onclick="window.history.back()">
                                back
                            </button>
                            <button class="btn-cancel btn btn-primary d-none" onClick="window.location.reload();">
                                cancel
                            </button>
                            <button type="submit" form="form-update-homework"
                                class="btn-save btn btn-success btn-custom-green d-none">
                                Save
                            </button>
                            <button type="button" class="btn-edit btn btn-success btn-custom-green">
                                Edit
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h5>Time Slot</h5>
                        </div>

                        <div class="card-tools">
                            <button type="button" class="btn-add btn btn-outline-primary px-4 d-none" onclick="AddRow()">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form id="form-update-homework" action="{{ route('homework.update', $branchId) }}" method="post">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="day_of_week" value="{{ $dayOfWeek }}">

                            <div class="time-slot-group-wrap">
                                @foreach ($homeworkTimeSlots as $homeworkTimeSlot)
                                    <div id="time-slot-group-{{ $loop->index }}"
                                        class="row px-md-2 px-1 pt-2 mb-4 display-group-grey time-slot-group">
                                        <div class="col-12 col-md-4">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label class="font-weight-normal"
                                                        data-target="#start-time-{{ $loop->index }}"
                                                        data-toggle="datetimepicker">Start Time*</label>

                                                    <div class="input-group timepicker" id="start-time-{{ $loop->index }}"
                                                        data-target-input="nearest">
                                                        <input type="text"
                                                            name="time_slot[{{ $loop->index }}][start_time]"
                                                            value="{{ date('h:i A', strtotime($homeworkTimeSlot->start_time)) }}"
                                                            class="start_time form-control datetimepicker-input"
                                                            data-target="#start-time-{{ $loop->index }}" required>
                                                        <div class="input-group-append"
                                                            data-target="#start-time-{{ $loop->index }}"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="bootstrap-timepicker">
                                                <div class="form-group">
                                                    <label class="font-weight-normal"
                                                        data-target="#end-time-{{ $loop->index }}"
                                                        data-toggle="datetimepicker">End Time*</label>

                                                    <div class="input-group timepicker" id="end-time-{{ $loop->index }}"
                                                        data-target-input="nearest">
                                                        <input type="text" name="time_slot[{{ $loop->index }}][end_time]"
                                                            value="{{ date('h:i A', strtotime($homeworkTimeSlot->end_time)) }}"
                                                            class="end_time form-control datetimepicker-input"
                                                            data-target="#end-time-{{ $loop->index }}" required>
                                                        <div class="input-group-append"
                                                            data-target="#end-time-{{ $loop->index }}"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <label class="font-weight-normal"
                                                    for="teacher-{{ $loop->index }}">Teacher*</label>

                                                <select class="teacher_id form-control"
                                                    name="time_slot[{{ $loop->index }}][teacher_id]"
                                                    id="teacher-{{ $loop->index }}" required>
                                                    <option value="">Select Teacher</option>

                                                    @foreach ($teachers as $teacher)
                                                        <option value="{{ $teacher->id }}"
                                                            {{ $teacher->id == old('teacher_id') || $teacher->id == $homeworkTimeSlot->teacher->id ? 'selected' : '' }}>
                                                            {{ $teacher->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-end pb-3">
                                            <button type="button" class="btn-remove btn btn-danger d-none"
                                                onclick="RemoveRow('{{ $loop->index }}')">
                                                remove
                                            </button>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form-update-homework').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Please check all the fields'
                        })
                    }
                },
            })

            $('.timepicker').each(function() {
                $(this).datetimepicker({
                    format: 'hh:mm A'
                })
            })

            $('.btn-edit').click(function() {
                $('form :input').prop("disabled", false);

                $('.btn-back').addClass("d-none");
                $('.btn-edit').addClass("d-none");

                $('.btn-save').removeClass("d-none");
                $('.btn-cancel').removeClass("d-none");
                $('.btn-add').removeClass("d-none");
                $('.btn-remove').removeClass("d-none");
            })
        });

        function AddRow() {
            var nextNumber = $('.time-slot-group').length;

            $('.time-slot-group-wrap').append(`
                <div id="time-slot-group-` + nextNumber + `" class="row px-md-2 px-1 pt-2 mb-4 display-group-grey time-slot-group">
                    <div class="col-12 col-md-4">
                        <div class="bootstrap-timepicker">
                            <div class="form-group">
                                <label class="font-weight-normal"
                                    data-target="#start-time-` + nextNumber + `"
                                    data-toggle="datetimepicker">Start Time*</label>

                                <div class="input-group timepicker" id="start-time-` + nextNumber + `"
                                    data-target-input="nearest">
                                    <input type="text" name="time_slot[` + nextNumber + `][start_time]"
                                        class="form-control datetimepicker-input"
                                        data-target="#start-time-` + nextNumber + `" required>
                                    <div class="input-group-append"
                                        data-target="#start-time-` + nextNumber + `"
                                        data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="bootstrap-timepicker">
                            <div class="form-group">
                                <label class="font-weight-normal"
                                    data-target="#end-time-` + nextNumber + `"
                                    data-toggle="datetimepicker">End Time*</label>

                                <div class="input-group timepicker" id="end-time-` + nextNumber + `"
                                    data-target-input="nearest">
                                    <input type="text" name="time_slot[` + nextNumber + `][end_time]"
                                        class="form-control datetimepicker-input"
                                        data-target="#end-time-` + nextNumber + `" required>
                                    <div class="input-group-append"
                                        data-target="#end-time-` + nextNumber + `"
                                        data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <label class="font-weight-normal"
                                for="teacher-` + nextNumber + `">Teacher*</label>

                            <select class="form-control" name="time_slot[` + nextNumber + `][teacher_id]"
                                id="teacher-` + nextNumber + `" required>
                                <option value="">Select Teacher</option>

                                @foreach ($teachers as $teacher)
                                    <option value="{{ $teacher->id }}" {{ $teacher->id == old('teacher_id') ? 'selected' : '' }}>
                                        {{ $teacher->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-end pb-3">
                        <button type="button" class="btn-remove btn btn-danger"
                        onclick="RemoveRow('` + nextNumber + `')">
                            remove
                        </button>
                    </div>
                </div>
        `);

            $('.timepicker').each(function() {
                $(this).datetimepicker({
                    format: 'hh:mm A'
                })
            })
        }

        function RemoveRow(targetRow) {
            $('#time-slot-group-' + targetRow).remove();
            ReAssignInputName();
        }

        function ReAssignInputName() {
            var startTimeIndex = 0;
            $('.start_time').each(function() {
                $(this).attr('name', 'time_slot[' + startTimeIndex + '][start_time]');
                startTime++;
            })

            var endTimeIndex = 0;
            $('.end_time').each(function() {
                $(this).attr('name', 'time_slot[' + endTimeIndex + '][end_time]');
                endTime++;
            })

            var teacherIdIndex = 0;
            $('.teacher_id').each(function() {
                $(this).attr('name', 'time_slot[' + teacherIdIndex + '][teacher_id]');
                teacherId++;
            })
        }
    </script>
@endsection
