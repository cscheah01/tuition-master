@extends('layout/layout')

@section('page_title', 'Homework Time Slot')

@section('content')
    <div class="container-fluid px-sm-4">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2 px-0">
                    <div class="col px-0">
                        <h1 class="m-0 d-none d-sm-block">Homework Time Slot</h1>
                        <h4 class="m-0 d-block d-sm-none">Homework Time Slot</h4>
                    </div>
                    <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                        <div class="float-sm-right">

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="card collapsed-card mobile-collapsed-card mb-5">
            <div class="card-header d-sm-none">
                <h3 class="card-title"><i class="fas fa-search pr-2"></i>Search</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool collapsed-btn" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form id="form-filter">
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label for="filter-branch">Branch</label>
                                <select id="filter-branch" class="filter-branch form-control custom-select"
                                    style="width: 100%;">
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->id }}"
                                            {{ auth()->user()->branch_id == $branch->id ? 'selected' : '' }}>
                                            {{ $branch->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" class="btn btn-default" onclick="ResetForm('#form-filter');">
                        Reset
                    </button>
                    <button type="submit" class="btn btn-search btn-primary" form="form-filter">
                        Search
                    </button>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                @include('homework/index-table')
            </div>
        </div>
    </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table-homework').DataTable({
                "sDom": "",
                "ordering": false,
            });


            $("#form-filter").submit(function(e) {
                e.preventDefault();

                var filters = {
                    branch: $(".filter-branch").val()
                };

                var url = '{{ route('homework.datatable', ':branchId') }}';
                url = url.replace(':branchId', filters.branch);

                $("#table-homework").load(url);
            });
        });
    </script>
@endsection
