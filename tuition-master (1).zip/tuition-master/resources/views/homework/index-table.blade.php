<table id="table-homework" class="table table-bordered dt-responsive" style="width: 100%;">
    <thead>
        <tr>
            <th style="width: 10px;">Name</th>
            <th>Time Slot</th>
            <th style="width: 10px;">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($dayOfWeek as $dayEnumValue => $dayName)
            <tr>
                <td style="width: 10px;">{{ $dayName }}</td>
                <td>
                    @foreach ($homeworkTimeSlots->where('day_of_week', $dayEnumValue) as $homeworkTimeSlot)
                        <div class='badge badge-primary'>
                            <div>
                                {{ date('h:i A', strtotime($homeworkTimeSlot->start_time)) }} -
                                {{ date('h:i A', strtotime($homeworkTimeSlot->end_time)) }}
                            </div>

                            <div class="text-dark pt-1">
                                Teacher:
                                {{ $homeworkTimeSlot->teacher->name }}
                            </div>
                        </div>
                    @endforeach
                </td>
                <td style="width: 10px;">
                    <a class="btn btn-outline-primary mr-1"
                        href="{{ route('homework.show', ['branchId' => $branchId, 'dayOfWeek' => $dayEnumValue]) }}">
                        <i class="fas fa-edit"></i>
                    </a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
