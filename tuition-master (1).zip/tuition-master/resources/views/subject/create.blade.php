@extends('layout/layout')

@section('page_title', 'Add Subject')

@section('content')
<div class="container">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col d-flex flex-row-reverse pr-0">
                    <a class="btn btn-default" href="{{ route('subject.index') }}">back</a>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col text-center">
                    <h1 class="m-0 d-none d-sm-block">Add Subject</h1>
                    <h4 class="m-0 d-sm-none">Add Subject</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card">
        <div class="card-body py-3 py-md-5 px-4 px-md-5">
            <form id="form-create-subject" action="{{ route('subject.store') }}" method="post">
                @csrf

                <div class="row">
                    <div class="col mb-2 text-center">
                        <h4 class="mb-0 d-none d-sm-block">Branch</h4>
                        <h5 class="d-sm-none">Branch</h5>
                    </div>
                </div>
                <div class="row justify-content-center px-md-4 mb-4">
                    <div class="col-12 col-sm-6">
                        <div class="form-group">
                            <select class="form-control" name="branch_id" required>
                                <option value="">Select Branch</option>

                                @foreach ($branches as $branch)
                                    <option value="{{ $branch->id }}"
                                        {{ $branch->id == old('branch_id') ? 'selected' : '' }}>
                                        {{ $branch->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row pr-md-4">
                    <div class="col mb-2">
                        <h4 class="mb-0 d-none d-sm-block">Subject Details</h4>
                        <h5 class="d-sm-none">Subject Details</h5>
                    </div>
                </div>
                <div class="row px-md-4 mb-4">
                    <div class="col-12 col-sm-6">
                        <div class="form-group">
                            <label class="font-weight-normal" for="name">Name*</label>
                            <input type="text" name="name" value="{{ old('name') }}" id="name" class="form-control"
                                placeholder="Enter Name" required>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6">
                        <div class="form-group">
                            <label class="font-weight-normal" for="education-level">Education Level*</label>
                            <select class="form-control" name="education_level_id" id="education-level" required>
                                <option value="">Select Education Level</option>

                                @foreach ($educationLevels as $educationLevel)
                                    <option value="{{ $educationLevel->id }}"
                                        {{ $educationLevel->id == old('education_level_id') ? 'selected' : '' }}>
                                        {{ $educationLevel->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <hr>

                <div class="row mb-3">
                    <div class="col-auto">
                        <h4 class="mb-0 d-none d-sm-block">Available Time</h4>
                        <h5 class="d-sm-none">Available Time</h5>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-outline-primary px-4" onclick="AddAvailableTime()">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>

                <div class="available-time-input">
                    <div id="available-time-group-0"
                        class="row px-md-4 pt-2 mb-4 display-group-grey available-time-group">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal" for="day-of-week-0">Day*</label>

                                <select class="form-control" name="day_of_week[0]" id="day-of-week-0" required>
                                    <option value="">Select Day</option>
                                    @foreach ($dayOfWeek as $value => $description)
                                        <option value="{{ $value }}"
                                            {{ $value == old('day_of_week') ? 'selected' : '' }}>
                                            {{ $description }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label class="font-weight-normal" data-target="#start-time-0"
                                        data-toggle="datetimepicker">Start Time*</label>

                                    <div class="input-group timepicker" id="start-time-0" data-target-input="nearest">
                                        <input type="text" name="start_time[0]"
                                            class="form-control datetimepicker-input" data-target="#start-time-0"
                                            required>
                                        <div class="input-group-append" data-target="#start-time-0"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label class="font-weight-normal" data-target="#end-time-0"
                                        data-toggle="datetimepicker">End Time*</label>

                                    <div class="input-group timepicker" id="end-time-0" data-target-input="nearest">
                                        <input type="text" name="end_time[0]" class="form-control datetimepicker-input"
                                            data-target="#end-time-0" required>
                                        <div class="input-group-append" data-target="#end-time-0"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal" for="teacher-0">Teacher*</label>

                                <select class="form-control" name="teacher_id[0]" id="teacher-0" required>
                                    <option value="">Select Teacher</option>

                                    @foreach ($teachers as $teacher)
                                        <option value="{{ $teacher->id }}"
                                            {{ $teacher->id == old('teacher_id') ? 'selected' : '' }}>
                                            ({{ $teacher->branch->name }}) {{ $teacher->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal" for="classroom-0">Classroom*</label>

                                <select class="form-control" name="classroom_id[0]" id="classroom-0" required>
                                    <option value="">Select Classroom</option>

                                    @foreach ($classrooms as $classroom)
                                        <option value="{{ $classroom->id }}"
                                            {{ $classroom->id == old('classroom_id') ? 'selected' : '' }}>
                                            ({{ $classroom->branch->name }}) {{ $classroom->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>


            </form>

        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-danger mr-1"
                    onclick="ResetForm('#form-create-subject');">Reset</button>
                <button type="submit" form="form-create-subject" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>

@endsection


@section('script')
<script>
    $(function() {
        $('#form-create-subject').validate({
            errorElement: 'span',
            errorPlacement: function(error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function(element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            invalidHandler: function(form, validator) {
                var errors = validator.numberOfInvalids();
                if (errors) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Please check all the fields'
                    })
                }
            },
        })

        $('.timepicker').each(function() {
            $(this).datetimepicker({
                format: 'hh:mm A'
            })
        })

    });

    function AddAvailableTime() {
        var nextNumber = $('.available-time-group').length;

        $('.available-time-input').append(`
            <div id="available-time-group-` + nextNumber + `" class="row px-md-4 pt-2 mb-4 display-group-grey available-time-group">
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label class="font-weight-normal" for="day-of-week-` + nextNumber + `">Day*</label>

                        <select class="form-control day_of_week" name="day_of_week[` + nextNumber +
            `]" id="day-of-week-` + nextNumber + `" required>
                            <option value="">Select Day</option>
                            @foreach ($dayOfWeek as $value => $description)
                                <option value="{{ $value }}" {{ $value == old('day_of_week') ? 'selected' : '' }}>{{ $description }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label class="font-weight-normal" data-target="#start-time-` + nextNumber + `" data-toggle="datetimepicker">
                                Start Time*
                            </label>

                            <div class="input-group timepicker" id="start-time-` + nextNumber + `" data-target-input="nearest">
                                <input type="text" name="start_time[` + nextNumber +
            `]" class="form-control datetimepicker-input start_time" data-target="#start-time-` + nextNumber + `" required>
                                <div class="input-group-append" data-target="#start-time-` + nextNumber + `" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-clock"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label class="font-weight-normal" data-target="#end-time-` + nextNumber + `" data-toggle="datetimepicker">
                                End Time*
                            </label>

                            <div class="input-group timepicker" id="end-time-` + nextNumber + `" data-target-input="nearest">
                                <input type="text" name="end_time[` + nextNumber +
            `]" class="form-control datetimepicker-input end_time" data-target="#end-time-` + nextNumber + `" required>
                                <div class="input-group-append" data-target="#end-time-` + nextNumber + `" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-clock"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label class="font-weight-normal" for="teacher-` + nextNumber + `">Teacher*</label>

                        <select class="form-control teacher_id" name="teacher_id[` + nextNumber + `]"
                        id="teacher-` + nextNumber + `" required>
                            <option value="">Select Teacher</option>

                            @foreach ($teachers as $teacher)
                                <option value="{{ $teacher->id }}" {{ $teacher->id == old('teacher_id') ? 'selected' : '' }}>
                                    ({{ $teacher->branch->name }}) {{ $teacher->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label class="font-weight-normal" for="classroom-` + nextNumber + `">Classroom*</label>

                        <select class="form-control classroom_id" name="classroom_id[` + nextNumber + `]"
                        id="classroom-` + nextNumber + `" required>
                            <option value="">Select Classroom</option>

                            @foreach ($classrooms as $classroom)
                                <option value="{{ $classroom->id }}" {{ $classroom->id == old('classroom_id') ? 'selected' : '' }}>
                                    ({{ $classroom->branch->name }}) {{ $classroom->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-end pb-3">
                    <button type="button" class="btn btn-danger" onclick="RemoveAvailableTime(` + nextNumber + `);">
                        remove
                    </button>
                </div>
            </div>
        `);

        $('.timepicker').each(function() {
            $(this).datetimepicker({
                format: 'hh:mm A'
            })
        })
    }

    function RemoveAvailableTime(targetRow) {
        $('#available-time-group-' + targetRow).remove();
        ReAssignInputName();
    }

    function ReAssignInputName() {
        var dayOfWeek = 1;
        $('.day_of_week').each(function() {
            $(this).attr('name', 'day_of_week[' + dayOfWeek + ']');
            dayOfWeek++;
        })

        var startTime = 1;
        $('.start_time').each(function() {
            $(this).attr('name', 'start_time[' + startTime + ']');
            startTime++;
        })

        var endTime = 1;
        $('.end_time').each(function() {
            $(this).attr('name', 'end_time[' + endTime + ']');
            endTime++;
        })

        var teacherId = 1;
        $('.teacher_id').each(function() {
            $(this).attr('name', 'teacher_id[' + teacherId + ']');
            teacherId++;
        })

        var classroomId = 1;
        $('.classroom_id').each(function() {
            $(this).attr('name', 'classroom_id[' + classroomId + ']');
            classroomId++;
        })
    }
</script>
@endsection
