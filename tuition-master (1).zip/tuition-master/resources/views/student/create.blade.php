@extends('layout/layout')

@section('page_title', 'Register Student')

@section('content')
    <div class="container">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col d-flex flex-row-reverse pr-0">
                        <a class="btn btn-default" href="{{ route('student.index') }}">back</a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col text-center">
                        <h1 class="m-0 d-none d-sm-block">Student Registration From</h1>
                        <h4 class="m-0 d-sm-none">Student<br>Registration From</h4>
                    </div>
                </div>
            </div>
        </div>


        <div class="card">
            <div class="card-body py-3 py-md-5 px-4 px-md-5">
                <form action="">
                    <div class="row">
                        <div class="col mb-2 text-center">
                            <h4 class="mb-0 d-none d-sm-block">Branch</h4>
                            <h5 class="d-sm-none">Branch</h5>
                        </div>
                    </div>
                    <div class="row justify-content-center px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Branch</option>
                                    <option value="">123</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row pr-md-4">
                        <div class="col mb-2">
                            <h4 class="mb-0 d-none d-sm-block">Student Details</h4>
                            <h5 class="d-sm-none">Student Details</h5>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="student-name-ch" class="font-weight-normal">Name (CN)*</label>
                                <input type="text" class="form-control" id="student-name-ch" placeholder="Name (中)">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="student-name-en" class="font-weight-normal">Name (EN)*</label>
                                <input type="text" class="form-control" id="student-name-en" placeholder="Name (EN)">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Gender*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Gender</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Date of Birth*</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                    </div>
                                    <input type="text" class="form-control" data-inputmask-alias="datetime"
                                        data-inputmask-inputformat="dd/mm/yyyy" data-mask>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Education Level*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Education Level</option>
                                    <option value="Y1">Y1</option>
                                    <option value="Y2">Y2</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">School*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select School</option>
                                    <option value="kk1">kk1</option>
                                    <option value="kk2">kk2</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="student-contact" class="font-weight-normal">Student Phone Number</label>
                                <input type="text" class="form-control" id="student-contact" placeholder="(If have)">
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row pr-md-4">
                        <div class="col-auto mb-2">
                            <h4 class="mb-0 d-none d-sm-block">Contact Info</h4>
                            <h5 class="mb-0 d-sm-none">Contact Info</h5>
                            <span class="text-secondary d-none d-sm-block">*Tick 1 number for primary contact</span>
                            <span class="text-secondary d-sm-none">*Tick 1 number for<br>&nbsp; primary contact</span>
                        </div>
                        <div class="col text-right">
                            <button type="button" class="btn btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal" for="mum-contact">Mum</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="fas fa-phone-alt"></i>
                                        </span>
                                    </div>
                                    <input type="text" class="form-control" id="mum-contact">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <input type="checkbox">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal" for="dad-contact">Dad</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="fas fa-phone-alt"></i>
                                        </span>
                                    </div>
                                    <input type="text" class="form-control" id="dad-contact">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <input type="checkbox">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-block">Address Details</h4>
                            <h5 class="d-sm-none">Address Details</h5>
                        </div>
                        <div class="col text-right">
                            <button type="button" class="btn btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 pt-2 mb-4 display-group-grey">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Address Name*</label>
                                <input type="text" class="form-control" placeholder="Address Name">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Address*</label>
                                <input type="text" class="form-control" placeholder="xx , Jalan xxx">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Area*</label>
                                <select class="form-control select2bs4" style="width: 100%;">
                                    <option value="default" selected="selected" disabled="disabled">Select Area</option>
                                    <option value="">Taman xx</option>
                                    <option value="">Taman xx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Remark</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-block">Tuition Package</h4>
                            <h5 class="d-sm-none">Tuition Package</h5>
                        </div>
                        <div class="col text-right">
                            <button type="button" class="btn btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4">
                        <div class="col-12 col-md-8 col-xl-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Package 1*</label>
                                <select class="form-control select2bs4" style="width: 100%;">
                                    <option value="">Select Tuition Package</option>
                                    <option value="Tuition">Tuition</option>
                                    <option value="Childcare">Childcare</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row pr-md-4">
                        <div class="col mb-2">
                            <h4 class="mb-0 d-none d-sm-inline-block">Childcare Section</h4>
                            <h5 class="d-inline-block d-sm-none">Childcare Section</h5>

                            <div class="form-group d-inline-block ml-2">
                                <div class="custom-control custom-switch custom-switch-on-success">
                                    <input type="checkbox" class="custom-control-input" id="childcare-select-switch"
                                        data-target-field=".childcare-input-wrap" onchange="InputSwitchToggle(this)">
                                    <label class="custom-control-label" for="childcare-select-switch"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4 d-none childcare-input-wrap">
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Monday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Tuersday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Wednesday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Thursday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Friday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Saturday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Sunday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <hr>

                    <div class="row pr-4">
                        <div class="col mb-2">
                            <h4 class="mb-0 d-none d-sm-inline-block">Homework Section</h4>
                            <h5 class="d-inline-block d-sm-none">Homework Section</h5>
                            <div class="form-group d-inline-block ml-2">
                                <div class="custom-control custom-switch custom-switch-on-success">
                                    <input type="checkbox" class="custom-control-input" id="homework-select-switch"
                                        data-target-field=".homework-input-wrap" onchange="InputSwitchToggle(this)">
                                    <label class="custom-control-label" for="homework-select-switch"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4 d-none homework-input-wrap">
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Monday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Tuersday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Wednesday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Thursday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Friday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Saturday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><strong>Sunday</strong></h3>

                                    <div class="float-right">
                                        <button type="button" class="btn btn-sm btn-primary px-3">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <select class="form-control" style="width: 100%;">
                                                    <option value="">Select Time Slot</option>
                                                    <option value="">xxx</option>
                                                    <option value="">xxx</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-inline-block">Tuition Section</h4>
                            <h5 class="d-inline-block d-sm-none">Tuition Section</h5>

                            <div class="form-group d-inline-block ml-2">
                                <div class="custom-control custom-switch custom-switch-on-success">
                                    <input type="checkbox" class="custom-control-input" id="tuition-select-switch"
                                        data-target-field=".tuition-input-wrap" onchange="InputSwitchToggle(this)">
                                    <label class="custom-control-label" for="tuition-select-switch"></label>
                                </div>
                            </div>
                        </div>
                        <div class="col text-right d-none tuition-input-wrap">
                            <button type="button" class="btn btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 pt-2 mb-4 display-group-grey d-none tuition-input-wrap">
                        <div class="col-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Level*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="default" selected="selected" disabled="disabled">Select Level</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="form-group">
                                <label class="font-weight-normal">Subject*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="default" selected="selected" disabled="disabled">Select Subject</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Time Slot*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="default" selected="selected" disabled="disabled">Select Time Slot
                                    </option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-inline-block">1 to 1 Section</h4>
                            <h5 class="d-inline-block d-sm-none">1 to 1 Section</h5>

                            <div class="form-group d-inline-block ml-2">
                                <div class="custom-control custom-switch custom-switch-on-success">
                                    <input type="checkbox" class="custom-control-input" id="1to1-select-switch"
                                        data-target-field=".1to1-input-wrap" onchange="InputSwitchToggle(this)">
                                    <label class="custom-control-label" for="1to1-select-switch"></label>
                                </div>
                            </div>
                        </div>
                        <div class="col text-right d-none 1to1-input-wrap">
                            <button type="button" class="btn btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4 pt-2 display-group-grey d-none 1to1-input-wrap">
                        <div class="col-6 col-sm-4">
                            <div class="form-group">
                                <label class="font-weight-normal">Day*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Day</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-4">
                            <div class="form-group">
                                <label class="font-weight-normal">Level*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Level</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-4">
                            <div class="form-group">
                                <label class="font-weight-normal">Subject*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Subject</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-4">
                            <div class="form-group">
                                <label class="font-weight-normal">Teacher*</label>
                                <select class="form-control" style="width: 100%;">
                                    <option value="">Select Teacher</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label class="font-weight-normal">Start Time*</label>

                                    <div class="input-group date" id="start-time" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input"
                                            data-target="#start-time" />
                                        <div class="input-group-append" data-target="#start-time"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-sm-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label class="font-weight-normal">End Time*</label>

                                    <div class="input-group date" id="end-time" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input"
                                            data-target="#end-time" />
                                        <div class="input-group-append" data-target="#end-time"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-inline-block">Transport</h4>
                            <h5 class="d-inline-block d-sm-none">Transport</h5>

                            <div class="form-group d-inline-block ml-2">
                                <div class="custom-control custom-switch custom-switch-on-success">
                                    <input type="checkbox" class="custom-control-input" id="transport-select-switch"
                                        data-target-field=".transport-input-wrap" onchange="InputSwitchToggle(this)">
                                    <label class="custom-control-label" for="transport-select-switch"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-2 d-none transport-input-wrap">
                        <div class="col-auto">
                            <span>Monday</span>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-sm btn-outline-primary px-4">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4 pt-3 display-group-grey d-none transport-input-wrap">
                        <div class="col-12">Come</div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Time</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Address</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Driver</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Remark">
                            </div>
                        </div>

                        <div class="col-12"></div>

                        <div class="col-12">Back</div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Time</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Address</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <select class="form-control custom-select" style="width: 100%;">
                                    <option value="">Driver</option>
                                    <option value="">xxx</option>
                                    <option value="">xxx</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6 col-sm-3">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Remark">
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row mb-3 pr-md-4">
                        <div class="col-auto">
                            <h4 class="mb-0 d-none d-sm-inline-block">For office uses only</h4>
                            <h5 class="d-inline-block d-sm-none">For office uses only</h5>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4 pt-3">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Register Date*</label>
                                <input type="text" class="form-control single-datepicker">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Starting Date*</label>
                                <input type="text" class="form-control single-datepicker">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Person In Charge*</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal">Allergies (Food / Medicine)</label>
                                <textarea class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="font-weight-normal">Remark For Student</label>
                                <textarea class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" class="btn btn-danger mr-1">Clear</button>
                    <button type="button" class="btn btn-primary">Register</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script>
        $(function() {
            $("input[data-bootstrap-switch]").each(function() {
                $(this).bootstrapSwitch('state', $(this).prop('checked'));
            });
            $('#start-time, #end-time').datetimepicker({
                format: 'LT'
            });
            $('[data-mask]').inputmask();
            $(".single-datepicker").daterangepicker({
                singleDatePicker: true,
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Close',
                    format: 'DD-MM-YYYY'
                }
            });
        });


        function InputSwitchToggle(switchBtn) {
            var targetField = switchBtn.getAttribute('data-target-field');

            if ($(switchBtn).is(":checked")) {
                $(targetField).removeClass('d-none');
            } else if ($(switchBtn).is(":not(:checked)")) {
                $(targetField).addClass('d-none');
            }

        }
    </script>
@endsection
