@extends('layout/layout')

@section('page_title', 'Student List')

@section('content')
<div class="container-fluid px-sm-4">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Student List</h1>
                    <h4 class="m-0 d-block d-sm-none">Student List</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a type="button" class="btn btn-success btn-custom-green" href="{{route('student.create')}}">
                            Register Student
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card collapsed-card mobile-collapsed-card mb-5">
        <div class="card-header d-sm-none">
            <h3 class="card-title"><i class="fas fa-search pr-2"></i>Search</h3>

            <div class="card-tools">
                <button type="button" class="btn btn-tool collapsed-btn" data-card-widget="collapse">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Branch</label>
                        <select class="form-control custom-select">
                            <option value="">All</option>
                            <option value="">xxx</option>
                            <option value="">xxx</option>
                        </select>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Student Id</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Name (EN)</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Name (CN)</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Education Level</label>
                        <select class="form-control custom-select">
                            <option value="">All</option>
                            <option value="">xxx</option>
                            <option value="">xxx</option>
                        </select>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>School</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>Address</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default">
                    Reset
                </button>
                <button type="button" class="btn btn-primary">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped table-hover cursor-pointer data-table">
            <thead>
                <tr>
                    <th>Branch</th>
                    <th>Student Id</th>
                    <th>Name (EN)</th>
                    <th>Name (CN)</th>
                    <th>LV</th>
                    <th>Primary Contact</th>
                    <th>Address</th>
                    <th>School</th>
                    <th>
                        <i class="fas fa-ellipsis-h"></i>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        a
                    </td>
                    <td>
                        00001
                    </td>
                    <td>
                        Woon Li Qi
                    </td>
                    <td>
                        温力齐
                    </td>
                    <td>
                        Y1
                    </td>
                    <td>
                        011-2345678
                    </td>
                    <td>
                        xx, Jalan xxxxxx xxxxx
                    </td>
                    <td>
                        SJKC(c)KK1
                    </td>
                    <td>

                    </td>
                </tr>
                <tr>
                    <td>
                        a
                    </td>
                    <td>
                        00001
                    </td>
                    <td>
                        Woon Li Qi
                    </td>
                    <td>
                        温力齐
                    </td>
                    <td>
                        Y1
                    </td>
                    <td>
                        011-2345678
                    </td>
                    <td>
                        xx, Jalan xxxxxx xxxxx
                    </td>
                    <td>
                        SJKC(c)KK1
                    </td>
                    <td>

                    </td>
                </tr>
            </tbody>
            </table>
        </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    $(function () {

    });
</script>
@endsection


