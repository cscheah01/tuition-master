<footer class="main-footer text-center">
	<strong><a href="#">Tuition Management System</a></strong>
</footer>

