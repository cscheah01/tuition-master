<script>
    $(function() {
        //page response message timeout auto close
        setTimeout(function() {
            $('.page-head-response-alert').fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 2500);

        //datatable
        $('.data-table').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "pageLength": 20,
            "lengthMenu": [10, 20, 30, 50],
        });

        //select 2 (multi select)
        $('.select2').select2({
            theme: 'bootstrap4'
        })

        //bootstrap tab push to url and auto select from url on page load
        var hash = window.location.hash;
        hash && $('ul.nav a[href="' + hash + '"]').tab('show');

        $('.nav-tabs a').click(function(e) {
            $(this).tab('show');
            window.location.hash = this.hash;
            $(window).scrollTop(0);
        })

        //datatable bootstrap tab responsive (recalculate table column width after switching tab)
        $("a[data-toggle=\"pill\"]").on("shown.bs.tab", function(e) {
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust()
                .responsive.recalc();
        })
    });

    //sweet alert
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2500,
    })

    //trigger jquery validate if submit form return any error
    function ReValidateForm() {
        $("form").each(function() {
            $(this).valid();
        })
    }

    //form reset
    function ResetForm(targetForm) {
        $(targetForm)[0].reset();
        $(targetForm).validate().resetForm();
        Toast.close();
    }

    //remember sidebar collapse status
    function SidebarToggle() {
        $.ajax({
            type: "POST",
            url: "{{ route('sidebar.save_state') }}",
            data: {
                _token: "{{ csrf_token() }}"
            }
        })
    }
</script>
