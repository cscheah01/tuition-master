<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('page_title') | Tuition Management System</title>

    <link rel="icon" href="{{ asset('img/sm-logo.png') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
</head>

<body class="hold-transition sidebar-mini layout-navbar-fixed {{ Session::get('sidebarState') }}">
    <div class="wrapper">
        @include('layout/top-bar')
        @include('layout/side-bar')

        <div class="content-wrapper pb-5">
            <div class="content">
                @include('layout/message')
                @yield('content')
            </div>
        </div>

        @include('layout/footer')
    </div>

    <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>

    @include('layout/shared-script')
    @yield('script')

    @if (session('error'))
        <script>
            $(function() {
                ReValidateForm();
            })
        </script>
    @endif
</body>

</html>
