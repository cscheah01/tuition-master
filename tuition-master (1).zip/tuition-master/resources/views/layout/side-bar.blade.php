<aside class="main-sidebar sidebar-dark-olive elevation-4 position-fixed">
    <div class="brand-link">
        <img src="{{ asset('img/sm-logo.png') }}" class="brand-image img-circle elevation-3 bg-white">
        <span class="brand-text">Tuition Center</span>
    </div>

    <div class="sidebar" style="margin-top: 57px; height: calc(100vh - 57px);">
        <nav class="mt-2 pb-4">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="{{ route('dashboard') }}" class="nav-link {{ request()->is('/') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-muted">
                        <i class="nav-icon fas fa-cash-register"></i>
                        <p>
                            Sales Point
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-muted">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>
                            Timetable
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('student.index') }}"
                        class="nav-link {{ request()->is('student*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-user-graduate"></i>
                        <p>
                            Student
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-muted">
                        <i class="nav-icon fas fa-address-book"></i>
                        <p>
                            Phone Book
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('teacher.index') }}"
                        class="nav-link {{ request()->is('teacher*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-user-tie"></i>
                        <p>
                            Teacher
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-muted">
                        <i class="nav-icon far fa-calendar-check"></i>
                        <p>
                            Attendance
                        </p>
                    </a>
                </li>

                <li class="nav-header">Setting</li>

                <li class="nav-item">
                    <a href="{{ route('school.index') }}"
                        class="nav-link {{ request()->is('school*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-school"></i>
                        <p>
                            School
                        </p>
                    </a>
                </li>
                <li
                    class="nav-item has-treeview {{ request()->is('driver*') || request()->is('area*') ? 'menu-open' : '' }}">
                    <a href="#"
                        class="nav-link {{ request()->is('driver*') || request()->is('area*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-bus"></i>
                        <p>
                            Transport
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('driver.index') }}"
                                class="nav-link {{ request()->is('driver*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>Driver</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('area.index') }}"
                                class="nav-link {{ request()->is('area*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>Area</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li
                    class="nav-item has-treeview {{ request()->is('subject*') || request()->is('childcare*') || request()->is('homework*') ? 'menu-open' : '' }}">
                    <a href="#"
                        class="nav-link {{ request()->is('subject*') || request()->is('childcare*') || request()->is('homework*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-clock"></i>
                        <p>
                            Lessons / Time Slot
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('subject.index') }}"
                                class="nav-link {{ request()->is('subject*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>
                                    Subject
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('childcare.index') }}"
                                class="nav-link  {{ request()->is('childcare*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>
                                    Childcare
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('homework.index') }}"
                                class="nav-link  {{ request()->is('homework*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>
                                    Homework
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link text-muted">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>
                                    Activity
                                </p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li
                    class="nav-item has-treeview {{ request()->is('branch*') || request()->is('classroom*') ? 'menu-open' : '' }}">
                    <a href="#"
                        class="nav-link {{ request()->is('branch*') || request()->is('classroom*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-building"></i>
                        <p>
                            Center
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('branch.index') }}"
                                class="nav-link {{ request()->is('branch*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>Branch</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('classroom.index') }}"
                                class="nav-link {{ request()->is('classroom*') ? 'active' : '' }}">
                                <i class="fas fa-angle-right nav-icon"></i>
                                <p>Classroom</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
