@extends('layout/layout')

@section('page_title', 'Add Branch')

@section('content')
    <div class="container">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col d-flex flex-row-reverse pr-0">
                        <a class="btn btn-default" href="{{ route('branch.index') }}">back</a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col text-center">
                        <h1 class="m-0 d-none d-sm-block">Add Branch</h1>
                        <h4 class="m-0 d-sm-none">Add Branch</h4>
                    </div>
                </div>
            </div>
        </div>


        <div class="card">
            <div class="card-body py-3 py-md-5 px-4 px-md-5">
                <form id="form-create-branch" action="{{ route('branch.store') }}" method="post">
                    @csrf

                    <div class="row pr-md-4">
                        <div class="col mb-2">
                            <h4 class="mb-0 d-none d-sm-block">Branch Details</h4>
                            <h5 class="d-sm-none">Branch Details</h5>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal" for="name">Name*</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name"
                                    value="{{ old('name') }}" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal" for="phone-no">Phone Number*</label>
                                <input type="text" name="phone_no" id="phone-no" class="form-control"
                                    placeholder="Enter Phone Number" value="{{ old('phone_no') }}" required>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" class="btn btn-danger mr-1"
                        onclick="ResetForm('#form-create-branch');">Reset</button>
                    <button type="submit" class="btn btn-primary" form="form-create-branch">Save</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script>
        $(function() {
            $('#form-create-branch').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Please check all the fields'
                        })
                    }
                },
            })
        });
    </script>
@endsection
