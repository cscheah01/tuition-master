@extends('layout/layout')

@section('page_title', 'Classroom Details')

@section('content')
<div class="container-fluid px-sm-4">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col-sm-8 px-0">
                    <h1 class="m-0 d-none d-sm-block">Classroom Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Classroom Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <button class="btn-back btn btn-default" onclick="window.history.back()">
                            back
                        </button>
                        <button class="btn-delete btn btn-outline-danger" onclick="DeleteClassroom(event);">
                            <form id="form-delete-classroom" method="post" action="{{ route('classroom.destroy', $classroom->id) }}">
                                @csrf
                                @method('DELETE')
                            </form>
                            Delete
                        </button>
                        <button class="btn-cancel btn btn-primary d-none" onClick="window.location.reload();">
                            cancel
                        </button>
                        <button type="submit" form="form-update-classroom" class="btn-save btn btn-success btn-custom-green d-none">
                            Save
                        </button>
                        <button type="button" class="btn-edit btn btn-success btn-custom-green">
                            Edit
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div class="row">
        <div class="col-12 col-sm-6 col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5>Area</h5>
                </div>
                <div class="card-body">
                    <form id="form-update-classroom" action="{{route('classroom.update', $classroom->id)}}" method="post">
                        @csrf
                        @method('PATCH')

                        <div class="row">
                            <div class="col-6 col-sm-12">
                                <div class="form-group">
                                    <label class="font-weight-normal">Classroom</label>

                                    <select class="form-control" name="branch_id" required disabled>
                                        <option value="">Select Branch</option>

                                        @foreach($branches as $branch)
                                            <option value="{{ $branch->id }}" {{ ($branch->id) == old('branch_id') || ($branch->id) == ($classroom->branch->id) ? 'selected' : '' }}>{{ $branch->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-6 col-sm-12">
                                <div class="form-group">
                                    <label class="font-weight-normal">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter Name" value="{{$classroom->name}}" required disabled>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Classroom Schedule</h5>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</div>
@endsection


@section('script')
<script>
    $(function () {
        $('.btn-edit').click(function(){
            $('form :input').prop("disabled", false);

            $('.btn-back').addClass("d-none");
            $('.btn-delete').addClass("d-none");
            $('.btn-edit').addClass("d-none");

            $('.btn-save').removeClass("d-none");
            $('.btn-cancel').removeClass("d-none");
        })

        $('#form-update-classroom').validate({
            errorElement: 'span',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            invalidHandler: function(form, validator) {
                var errors = validator.numberOfInvalids();
                if (errors) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Please check all the fields'
                    })
                }
            },
        })

        DeleteClassroom = function(e){
            e.preventDefault();

            Swal.fire({
                title: 'Are you sure want to remove?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {
                    $('#form-delete-classroom').submit();
                }
            })
        };
    });
</script>
@endsection


