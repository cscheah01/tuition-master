
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password | Tuition Management System</title>

    <link rel="icon" href="{{ asset('img/sm-logo.png') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=Qhe5cGYIA5Bfvke_O08zeFwQIHUPgaivqhzIK2LZjWUrV18v1r5jR6t2kPxZnKi7Q5ia8V8Tc3llIjwmTW8iCbr1OArP5eVwvQ5O3CtQ3YdqIv78-K31xg0MgB9pDHXo" charset="UTF-8"></script>
</head>

<body class="hold-transition login-page">

    <div class="login-box">
        <div class="login-logo">
            <b>Tuition</b> System
        </div>

        <div class="card">
            <div class="card-body login-card-body">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif

                <p class="login-box-msg">
                    <b>Forgot your password?</b><br>
                    We will send you an email to reset your password.
                </p>

                <form id="form-forget-password"  method="POST" action="{{ route('password.email') }}">
                    @csrf

                    <div class="input-group mb-3">
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" placeholder="Email" required autocomplete="email" autofocus>
                        <div class="input-group-append">
                            <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn-send-forgot-password btn btn-primary btn-block">Submit</button>
                        </div>
                    </div>
                </form>

                <p class="mt-3 mb-1">
                    <a href="{{ route('login') }}"><i class="fas fa-long-arrow-alt-left"></i> Back to login</a>
                </p>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>


    <script>
        $(function () {
            $('#form-forget-password').validate({
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
            })

            $("#form-forget-password").submit(function(){
                if($("#form-forget-password").valid()) {
                    $('.btn-send-forgot-password').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submiting...');
                    $('.btn-send-forgot-password').prop('disabled', true);
                }
            })
        });
    </script>
</body>
</html>
