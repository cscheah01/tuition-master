
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Tuition Management System</title>

    <link rel="icon" href="{{ asset('img/sm-logo.png') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=Qhe5cGYIA5Bfvke_O08zeFwQIHUPgaivqhzIK2LZjWUrV18v1r5jR6t2kPxZnKi7Q5ia8V8Tc3llIjwmTW8iCbr1OArP5eVwvQ5O3CtQ3YdqIv78-K31xg0MgB9pDHXo" charset="UTF-8"></script>
</head>

<body class="hold-transition login-page">

    <div class="login-box">
        <div class="login-logo">
            <b>Tuition</b> System
        </div>

        <div class="card">
            <div class="card-body login-card-body">
                @if($errors->any())
                    <div class="alert alert-danger" role="alert">
                        {{ implode('<br>', $errors->all()) }}
                    </div>
                @endif

                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif

                <p class="login-box-msg">Please enter login details</p>

                <form id="form-login" method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Email" required autofocus
                            name="email"
                            value="{{ old('email') }}">

                        <div class="input-group-append">
                            <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>

                    <div class="input-group mb-3">
                        <input type="password" class="form-control" placeholder="Password" required
                            name="password">

                        <div class="input-group-append">
                            <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-8">
                            <a href="{{ route('password.request') }}">I forgot my password</a>
                        </div>
                        <div class="col-4">
                            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>


    <script>
        $(function () {
            $('#form-login').validate({
                rules: {
                    email: {
                        required: true
                    },
                    password: {
                        required: true
                    },
                },
                messages: {
                    email: "Please enter your email.",
                    password: "Please enter your password."
                },
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
</body>
</html>
