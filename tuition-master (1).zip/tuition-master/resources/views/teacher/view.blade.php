@extends('layout/layout')

@section('page_title', 'Teacher Details')

@section('content')
    <div class="container-fluid px-sm-4">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2 px-0">
                    <div class="col-sm-8 px-0">
                        <h1 class="m-0 d-none d-sm-block">Teacher Details</h1>
                        <h4 class="m-0 d-block d-sm-none">Teacher Details</h4>
                    </div>
                    <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                        <div class="float-sm-right">
                            <button class="btn-back btn btn-default" onclick="window.history.back()">
                                back
                            </button>
                            <button class="btn-delete btn btn-outline-danger" onclick="DeleteTeacher(event);">
                                <form id="form-delete-teacher" method="post"
                                    action="{{ route('teacher.destroy', $teacher->id) }}">
                                    @csrf
                                    @method('DELETE')
                                </form>
                                Delete
                            </button>
                            <button class="btn-cancel btn btn-primary d-none" onClick="window.location.reload();">
                                cancel
                            </button>
                            <button type="submit" form="form-update-teacher"
                                class="btn-save btn btn-success btn-custom-green d-none">
                                Save
                            </button>
                            <button type="button" class="btn-edit btn btn-success btn-custom-green">
                                Edit
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>


        <div class="row">
            <div class="col-12 col-md-7">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h5>Teacher</h5>
                        </div>

                        <div class="card-tools">
                            <button type="button" class="btn btn-success btn-custom-green" data-toggle="modal"
                                data-target="#modal-update-password">
                                <i class="fas fa-key"></i>
                                Update Password
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form id="form-update-teacher" action="{{ route('teacher.update', $teacher->id) }}" method="post">
                            @csrf
                            @method('PATCH')

                            <div class="row px-md-4 mb-4">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="branch">Branch*</label>
                                        <select class="form-control" name="branch_id" id="branch" disabled required>
                                            <option value="">Select Branch</option>

                                            @foreach ($branches as $branch)
                                                <option value="{{ $branch->id }}"
                                                    {{ ($branch->id == old('branch_id')) | ($branch->id == $teacher->branch_id) ? 'selected' : '' }}>
                                                    {{ $branch->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="name">Name*</label>
                                        <input type="text" name="name" value="{{ $teacher->name }}" id="name"
                                            class="form-control" placeholder="Enter Name" disabled required>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="gender">Gender*</label>
                                        <select class="form-control" name="gender" id="gender" disabled required>
                                            <option value="">Select Gender</option>
                                            @foreach ($genders as $value => $description)
                                                <option value="{{ $value }}"
                                                    {{ ($value == old('gender')) | ($value == $teacher->gender) ? 'selected' : '' }}>
                                                    {{ $description }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="phone-no">Phone Number*</label>
                                        <input type="text" name="phone_no" value="{{ $teacher->phone_no }}" id="phone-no"
                                            class="form-control" placeholder="Enter Phone Number" disabled required>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="email">Email*</label>
                                        <input type="text" name="email" value="{{ $teacher->email }}" id="email"
                                            class="form-control" placeholder="Enter Email" disabled required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="row px-md-4 mb-4">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="is-active">Account Status</label>
                                        <br>
                                        <input type="checkbox" name="is_active" id="is-active"
                                            {{ $teacher->is_active != null ? 'checked' : '' }} data-bootstrap-switch
                                            data-off-color="danger" data-on-color="success" data-on-text="Active"
                                            data-off-text="InActive" disabled>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="role">Role*</label>
                                        <select name="role_id" id="role" class="form-control" disabled required>
                                            <option value="">Select Role</option>

                                            @foreach ($roles as $role)
                                                <option value="{{ $role->id }}"
                                                    {{ ($role->id == old('role_id')) | ($role->id == $teacher->role_id) ? 'selected' : '' }}>
                                                    {{ $role->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <label class="font-weight-normal" for="remark">Remark</label>
                                        <textarea name="remark" id="remark" class="form-control" rows="3"
                                            disabled>{{ $teacher->remark }}</textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-update-password">
        <div class="modal-dialog modal-center">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Password</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-update-password" action="{{ route('teacher.update_password', $teacher->id) }}"
                        method="post">
                        @csrf

                        <div class="row px-2">
                            <div class="col-12 col-sm-8">
                                <div class="form-group">
                                    <label class="font-weight-normal" for="password">New Password*</label>
                                    <input type="password" name="password" id="password" class="form-control"
                                        placeholder="Enter New Password" required>
                                </div>
                            </div>
                            <div class="col-12 col-sm-8">
                                <div class="form-group">
                                    <label class="font-weight-normal" for="password-confirmation">Confirm Password*</label>
                                    <input type="password" name="password_confirmation" id="password-confirmation"
                                        class="form-control" placeholder="Enter New Password" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-check">
                                    <input type="checkbox" name="send_mail" class="form-check-input" id="send-mail" checked>
                                    <label class="form-check-label" for="send-mail">
                                        Send email notification to user
                                    </label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <div class="float-right">
                        <button type="button" class="btn btn-danger mr-1"
                            onclick="ResetForm('#form-update-password');">Reset</button>
                        <button type="submit" form="form-update-password" class="btn-save btn btn-success btn-custom-green">
                            Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('.btn-edit').click(function() {
                $('form :input').prop("disabled", false);

                $('.btn-back').addClass("d-none");
                $('.btn-delete').addClass("d-none");
                $('.btn-edit').addClass("d-none");

                $('.btn-save').removeClass("d-none");
                $('.btn-cancel').removeClass("d-none");

                $("input[data-bootstrap-switch]").each(function() {
                    $(this).bootstrapSwitch('disabled', false);
                })
            })

            $('#form-update-teacher').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Please check all the fields'
                        })
                    }
                },
            })

            $('#form-update-password').validate({
                rules: {
                    password: {
                        required: true,
                        minlength: 8
                    },
                    password_confirmation: {
                        required: true,
                        minlength: 8,
                        equalTo: '#password'
                    }
                },
                messages: {
                    password_confirmation: {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Please check all the fields'
                        })
                    }
                },
            })

            DeleteTeacher = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to remove?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#form-delete-teacher').submit();
                    }
                })
            };
        });
    </script>
@endsection
