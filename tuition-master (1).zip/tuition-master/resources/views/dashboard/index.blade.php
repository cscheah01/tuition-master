@extends('layout/layout')

@section('page_title', 'Dashboard')

@section('content')
	<div class="container-fluid px-sm-4">
		Dashboard


    </div>
@endsection
