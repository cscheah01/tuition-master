@extends('layout/layout')

@section('page_title', 'School Details')

@section('content')
<div class="container-fluid px-sm-4">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col-sm-8 px-0">
                    <h1 class="m-0 d-none d-sm-block">School Details</h1>
                    <h4 class="m-0 d-block d-sm-none">School Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <button class="btn-back btn btn-default" onclick="window.history.back()">
                            back
                        </button>
                        <button class="btn-delete btn btn-outline-danger" onclick="DeleteSchool(event);">
                            <form id="form-delete-school" method="post" action="{{ route('school.destroy', $school->id) }}">
                                @csrf
                                @method('DELETE')
                            </form>
                            Delete
                        </button>
                        <button class="btn-cancel btn btn-primary d-none" onClick="window.location.reload();">
                            cancel
                        </button>
                        <button type="submit" form="form-update-school" class="btn-save btn btn-success btn-custom-green d-none">
                            Save
                        </button>
                        <button type="button" class="btn-edit btn btn-success btn-custom-green">
                            Edit
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div class="row">
        <div class="col-12 col-sm-6 col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5>School</h5>
                </div>
                <div class="card-body">
                    <form id="form-update-school" action="{{route('school.update', $school->id)}}" method="post">
                        @csrf
                        @method('PATCH')

                        <div class="row">
                            <div class="col-6 col-sm-12">
                                <div class="form-group">
                                    <label class="font-weight-normal">Branch</label>

                                    <select class="form-control" name="branch_id" disabled required>
                                        <option value="">Select Branch</option>

                                        @foreach($branches as $branch)
                                            <option value="{{ $branch->id }}" {{ ($branch->id) == old('branch') || ($branch->id) == ($school->branch->id) ? 'selected' : '' }}>{{ $branch->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label class="font-weight-normal">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter Name" value="{{$school->name}}" disabled required>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Student List</h5>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</div>
@endsection


@section('script')
<script>
    $(function () {
        $('.btn-edit').click(function(){
            $('form :input').prop("disabled", false);

            $('.btn-back').addClass("d-none");
            $('.btn-delete').addClass("d-none");
            $('.btn-edit').addClass("d-none");

            $('.btn-save').removeClass("d-none");
            $('.btn-cancel').removeClass("d-none");
        })

        $('#form-update-school').validate({
            errorElement: 'span',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            invalidHandler: function(form, validator) {
                var errors = validator.numberOfInvalids();
                if (errors) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Please check all the fields'
                    })
                }
            },
        })

        DeleteSchool = function(e){
            e.preventDefault();

            Swal.fire({
                title: 'Are you sure want to remove?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {
                    $('#form-delete-school').submit();
                }
            })
        };
    });
</script>
@endsection


