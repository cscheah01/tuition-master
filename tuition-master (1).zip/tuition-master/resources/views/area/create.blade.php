@extends('layout/layout')

@section('page_title', 'Add Transport Area')

@section('content')
    <div class="container">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col d-flex flex-row-reverse pr-0">
                        <a class="btn btn-default" href="{{ route('area.index') }}">back</a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col text-center">
                        <h1 class="m-0 d-none d-sm-block">Add Transport Area</h1>
                        <h4 class="m-0 d-sm-none">Add Transport Area</h4>
                    </div>
                </div>
            </div>
        </div>


        <div class="card">
            <div class="card-body py-3 py-md-5 px-4 px-md-5">
                <form id="form-create-area" action="{{ route('area.store') }}" method="post">
                    @csrf

                    <div class="row">
                        <div class="col mb-2 text-center">
                            <h4 class="mb-0 d-none d-sm-block">Branch</h4>
                            <h5 class="d-sm-none">Branch</h5>
                        </div>
                    </div>
                    <div class="row justify-content-center px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <select class="form-control" name="branch_id" required>
                                    <option value="">Select Branch</option>

                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->id }}"
                                            {{ $branch->id == old('branch_id') ? 'selected' : '' }}>{{ $branch->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row pr-md-4">
                        <div class="col mb-2">
                            <h4 class="mb-0 d-none d-sm-block">Area Details</h4>
                            <h5 class="d-sm-none">Area Details</h5>
                        </div>
                    </div>
                    <div class="row px-md-4 mb-4">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="font-weight-normal" for="name">Name*</label>
                                <input type="text" name="name" value="{{ old('name') }}" id="name" class="form-control"
                                    placeholder="Enter Name" required>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" class="btn btn-danger mr-1"
                        onclick="ResetForm('#form-create-area');">Reset</button>
                    <button type="submit" form="form-create-area" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script>
        $(function() {
            $('#form-create-area').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Please check all the fields'
                        })
                    }
                },
            })
        });
    </script>
@endsection
