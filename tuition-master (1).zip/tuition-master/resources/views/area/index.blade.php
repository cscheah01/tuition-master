@extends('layout/layout')

@section('page_title', 'Area List')

@section('content')
    <div class="container-fluid px-sm-4">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2 px-0">
                    <div class="col px-0">
                        <h1 class="m-0 d-none d-sm-block">Area List</h1>
                        <h4 class="m-0 d-block d-sm-none">Area List</h4>
                    </div>
                    <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                        <div class="float-sm-right">
                            <a type="button" class="btn btn-success btn-custom-green" href="{{ route('area.create') }}">
                                Add Area
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="card collapsed-card mobile-collapsed-card mb-5">
            <div class="card-header d-sm-none">
                <h3 class="card-title"><i class="fas fa-search pr-2"></i>Search</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool collapsed-btn" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form id="form-filter">
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label for="filter-branch">Branch</label>
                                <select id="filter-branch" class="filter-branch form-control custom-select"
                                    style="width: 100%;">
                                    <option value="">All</option>

                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                            <div class="form-group">
                                <label for="filter-name">Name</label>
                                <input type="search" id="filter-name" class="filter-name form-control">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" class="btn btn-default" onclick="ResetForm('#form-filter');">
                        Reset
                    </button>
                    <button type="submit" class="btn btn-search btn-primary" form="form-filter">
                        Search
                    </button>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <table id="table-area" class="table table-bordered dt-responsive" style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Area Name</th>
                            <th class="d-none"></th>
                            <th>Branch</th>
                            <th>Student Count</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table-area').DataTable({
                "processing": true,
                "serverSide": true,
                "sDom": "ltipr",
                "ajax": {
                    "url": "{{ route('area.datatable') }}",
                    "dataType": "json",
                    "type": "POST",
                    "data": {
                        _token: "{{ csrf_token() }}"
                    }
                },
                "columns": [{
                        "data": "name",
                        "name": "areas.name"
                    },
                    {
                        "data": "branch_id",
                        "name": "areas.branch_id",
                        "visible": false
                    },
                    {
                        "data": "branch_name",
                        "name": "branch_name"
                    },
                    {
                        "data": "name",
                        "name": "areas.name"
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data) {
                            return `
                            <div class="d-flex">
                                <a class="btn btn-outline-primary mr-1" href="{{ URL::to('/area/${data.id}') }}">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form method="post" action="{{ URL::to('/area/${data.id}') }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-outline-danger" onclick="DeleteArea(event);">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
            });


            DeleteArea = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to remove?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#form-filter").submit(function(e) {
                e.preventDefault();

                var $table = $('#table-area').DataTable();

                var filters = {
                    branch: $(".filter-branch").val(),
                    name: $(".filter-name").val()
                };

                $table.column(0).search(filters.name);
                $table.column(1).search('\\b' + filters.branch + '\\b', true, false);
                $table.draw();
            });
        });
    </script>
@endsection
