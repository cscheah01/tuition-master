window.$ = window.jQuery = require('jquery');
window._ = require('lodash');
window.Popper = require('popper.js').default;
window.moment = require('moment');
window.Swal = require('sweetalert2');
require('bootstrap');
//admin-lte
require('admin-lte');
//DataTables
require('datatables.net-bs4');
require('datatables.net-buttons');
require('datatables.net-responsive');
//Select2
require('admin-lte/plugins/select2/js/select2.full.min.js');
//date-range-picker
require('admin-lte/plugins/daterangepicker/daterangepicker.js');
//Tempusdominus Bootstrap 4
require('admin-lte/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js');
//Bootstrap Switch
require('admin-lte/plugins/bootstrap-switch/js/bootstrap-switch.min.js');
//input mask
require('admin-lte/plugins/inputmask/jquery.inputmask');
//jquery-validation
require('admin-lte/plugins/jquery-validation/jquery.validate.min.js');
require('admin-lte/plugins/jquery-validation/additional-methods.min.js');


$(function () {
    //search form collapse responsive
    var allowAdjustCollapse = true;

    $(window).resize(function () {
        adjustCollapseCard();
    })

    var adjustCollapseCard = function (){
        var newWindowWidth = $(window).width();

        if (newWindowWidth < '576') {
            if(allowAdjustCollapse == true){
                $('.mobile-collapsed-card').CardWidget('collapse');
                allowAdjustCollapse = false;
            }
        }
        else
        {
            $('.mobile-collapsed-card').CardWidget('expand');
            allowAdjustCollapse = true;
        }
    }

    adjustCollapseCard();

    $("input[data-bootstrap-switch]").each(function(){
        $(this).bootstrapSwitch();
    })
});
