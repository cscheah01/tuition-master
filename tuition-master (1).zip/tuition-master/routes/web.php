<?php

use Laravel\Fortify\Features;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AreaController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\DriverController;


use App\Http\Controllers\SchoolController;
use App\Http\Controllers\SidebarController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\HomeworkController;
use App\Http\Controllers\ChildcareController;
use App\Http\Controllers\ClassroomController;
use App\Http\Controllers\TransportController;
use Laravel\Fortify\Http\Controllers\PasswordController;
use Laravel\Fortify\Http\Controllers\NewPasswordController;
use Laravel\Fortify\Http\Controllers\VerifyEmailController;
use Laravel\Fortify\Http\Controllers\RecoveryCodeController;
use Laravel\Fortify\Http\Controllers\RegisteredUserController;
use Laravel\Fortify\Http\Controllers\TwoFactorQrCodeController;
use Laravel\Fortify\Http\Controllers\PasswordResetLinkController;
use Laravel\Fortify\Http\Controllers\ProfileInformationController;
use Laravel\Fortify\Http\Controllers\ConfirmablePasswordController;
use Laravel\Fortify\Http\Controllers\AuthenticatedSessionController;
use Laravel\Fortify\Http\Controllers\ConfirmedPasswordStatusController;
use Laravel\Fortify\Http\Controllers\EmailVerificationPromptController;
use Laravel\Fortify\Http\Controllers\TwoFactorAuthenticationController;
use Laravel\Fortify\Http\Controllers\EmailVerificationNotificationController;
use Laravel\Fortify\Http\Controllers\TwoFactorAuthenticatedSessionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth', 'verified'])->group(function () {
    //sidebar
    Route::post('/sidebar/state', [SidebarController::class, 'saveState'])->name('sidebar.save_state');

    //dashboard
    Route::get('/', function () {
        return view('dashboard/index');
    })->name('dashboard');

    //branch
    Route::resource('branch', BranchController::class)
        ->except([
            'edit'
        ]);
    Route::post('/branch/datatable', [BranchController::class, 'dataTable'])->name('branch.datatable');

    //classroom
    Route::resource('classroom', ClassroomController::class)
        ->except([
            'edit'
        ]);
    Route::post('/classroom/datatable', [ClassroomController::class, 'dataTable'])->name('classroom.datatable');

    //subject
    Route::resource('subject', SubjectController::class)
        ->except([
            'edit'
        ]);
    Route::post('/subject/datatable', [SubjectController::class, 'dataTable'])->name('subject.datatable');

    //childcare
    Route::resource('childcare', ChildcareController::class)
        ->except([
            'edit',
            'show'
        ]);
    Route::get('/childcare/datatable/{branchId}', [ChildcareController::class, 'dataTable'])->name('childcare.datatable');
    Route::get('/childcare/branch/{branchId}/day/{dayOfWeek}', [ChildcareController::class, 'show'])->name('childcare.show');

    //homework
    Route::resource('homework', HomeworkController::class)
        ->except([
            'edit',
            'show'
        ]);
    Route::get('/homework/datatable/{branchId}', [HomeworkController::class, 'dataTable'])->name('homework.datatable');
    Route::get('/homework/branch/{branchId}/day/{dayOfWeek}', [HomeworkController::class, 'show'])->name('homework.show');

    //student
    Route::resource('student', StudentController::class)
        ->except([
            'edit'
        ]);

    //teacher
    Route::resource('teacher', TeacherController::class)
        ->except([
            'edit'
        ]);
    Route::post('/teacher/datatable', [TeacherController::class, 'dataTable'])->name('teacher.datatable');
    Route::post('/teacher/update-password/{id}', [TeacherController::class, 'updatePassword'])->name('teacher.update_password');

    //school
    Route::resource('school', SchoolController::class)
        ->except([
            'edit'
        ]);
    Route::post('/school/datatable', [SchoolController::class, 'dataTable'])->name('school.datatable');

    //area
    Route::resource('area', AreaController::class)
        ->except([
            'edit'
        ]);
    Route::post('/area/datatable', [AreaController::class, 'dataTable'])->name('area.datatable');

    //driver
    Route::resource('driver', DriverController::class)
        ->except([
            'edit'
        ]);
    Route::post('/driver/datatable', [DriverController::class, 'dataTable'])->name('driver.datatable');
    Route::post('/driver/update-password/{id}', [DriverController::class, 'updatePassword'])->name('driver.update_password');
});



//fortify auth

$enableViews = config('fortify.views', true);

// Authentication...
if ($enableViews) {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])
        ->middleware(['guest:' . config('fortify.guard')])
        ->name('login');
}

$limiter = config('fortify.limiters.login');
$twoFactorLimiter = config('fortify.limiters.two-factor');

Route::post('/login', [AuthenticatedSessionController::class, 'store'])
    ->middleware(array_filter([
        'guest:' . config('fortify.guard'),
        $limiter ? 'throttle:' . $limiter : null,
    ]));

Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
    ->name('logout');

// Password Reset...
if (Features::enabled(Features::resetPasswords())) {
    if ($enableViews) {
        Route::get('/forgot-password', [PasswordResetLinkController::class, 'create'])
            ->middleware(['guest:' . config('fortify.guard')])
            ->name('password.request');

        Route::get('/reset-password/{token}', [NewPasswordController::class, 'create'])
            ->middleware(['guest:' . config('fortify.guard')])
            ->name('password.reset');
    }

    Route::post('/forgot-password', [PasswordResetLinkController::class, 'store'])
        ->middleware(['guest:' . config('fortify.guard')])
        ->name('password.email');

    Route::post('/reset-password', [NewPasswordController::class, 'store'])
        ->middleware(['guest:' . config('fortify.guard')])
        ->name('password.update');
}

/*
// Registration...
if (Features::enabled(Features::registration())) {
    if ($enableViews) {
        Route::get('/register', [RegisteredUserController::class, 'create'])
            ->middleware(['guest:' . config('fortify.guard')])
            ->name('register');
    }

    Route::post('/register', [RegisteredUserController::class, 'store'])
        ->middleware(['guest:' . config('fortify.guard')]);
}
*/

// Email Verification...
if (Features::enabled(Features::emailVerification())) {
    if ($enableViews) {
        Route::get('/email/verify', [EmailVerificationPromptController::class, '__invoke'])
            ->middleware(['auth'])
            ->name('verification.notice');
    }

    Route::get('/email/verify/{id}/{hash}', [VerifyEmailController::class, '__invoke'])
        ->middleware(['auth', 'signed', 'throttle:6,1'])
        ->name('verification.verify');

    Route::post('/email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware(['auth', 'throttle:6,1'])
        ->name('verification.send');
}

// Profile Information...
if (Features::enabled(Features::updateProfileInformation())) {
    Route::put('/user/profile-information', [ProfileInformationController::class, 'update'])
        ->middleware(['auth'])
        ->name('user-profile-information.update');
}

// Passwords...
if (Features::enabled(Features::updatePasswords())) {
    Route::put('/user/password', [PasswordController::class, 'update'])
        ->middleware(['auth'])
        ->name('user-password.update');
}

// Password Confirmation...
if ($enableViews) {
    Route::get('/user/confirm-password', [ConfirmablePasswordController::class, 'show'])
        ->middleware(['auth'])
        ->name('password.confirm');
}

Route::get('/user/confirmed-password-status', [ConfirmedPasswordStatusController::class, 'show'])
    ->middleware(['auth'])
    ->name('password.confirmation');

Route::post('/user/confirm-password', [ConfirmablePasswordController::class, 'store'])
    ->middleware(['auth']);

// Two Factor Authentication...
if (Features::enabled(Features::twoFactorAuthentication())) {
    if ($enableViews) {
        Route::get('/two-factor-challenge', [TwoFactorAuthenticatedSessionController::class, 'create'])
            ->middleware(['guest:' . config('fortify.guard')])
            ->name('two-factor.login');
    }

    Route::post('/two-factor-challenge', [TwoFactorAuthenticatedSessionController::class, 'store'])
        ->middleware(array_filter([
            'guest:' . config('fortify.guard'),
            $twoFactorLimiter ? 'throttle:' . $twoFactorLimiter : null,
        ]));

    $twoFactorMiddleware = Features::optionEnabled(Features::twoFactorAuthentication(), 'confirmPassword')
        ? ['auth', 'password.confirm']
        : ['auth'];

    Route::post('/user/two-factor-authentication', [TwoFactorAuthenticationController::class, 'store'])
        ->middleware($twoFactorMiddleware)
        ->name('two-factor.enable');

    Route::delete('/user/two-factor-authentication', [TwoFactorAuthenticationController::class, 'destroy'])
        ->middleware($twoFactorMiddleware)
        ->name('two-factor.disable');

    Route::get('/user/two-factor-qr-code', [TwoFactorQrCodeController::class, 'show'])
        ->middleware($twoFactorMiddleware)
        ->name('two-factor.qr-code');

    Route::get('/user/two-factor-recovery-codes', [RecoveryCodeController::class, 'index'])
        ->middleware($twoFactorMiddleware)
        ->name('two-factor.recovery-codes');

    Route::post('/user/two-factor-recovery-codes', [RecoveryCodeController::class, 'store'])
        ->middleware($twoFactorMiddleware);
}
